# Skill Creator Changelog

## Version 1.1.0 - 2025-11-11

### Major Enhancements

This release significantly expands the YAML frontmatter documentation and updates the init_skill.py template based on lessons learned from the taskfile skill development.

#### 1. **Comprehensive YAML Frontmatter Documentation**

**Enhanced SKILL.md section**: "YAML Frontmatter Metadata"

**Expanded from 2 sentences to comprehensive guide including:**

**Required fields:**
- **name**: Lowercase, hyphenated identifier
  - Naming conventions
  - Special character restrictions
  - Examples: `pdf-editor`, `taskfile`, `design-doc-mermaid`

- **description**: Clear explanation with specific guidance
  - Third-person voice requirement
  - Use case specificity
  - Multi-line YAML support with `|`
  - Trigger scenario inclusion

**Recommended optional fields** (NEW):
- **version**: Semantic versioning (major.minor.patch)
  - Version tracking guidance
  - Semantic versioning explanation

- **triggers**: Array of trigger phrases
  - While not officially documented in Claude Code, useful for documentation
  - Common user phrases
  - Variations and abbreviations
  - Related terms and file extensions
  - Example: `- taskfile`, `- task runner`, `- Taskfile.yml`

- **category**: Broad categorization
  - Examples: `build-automation`, `documentation`, `data-processing`

- **author**: Creator/maintainer attribution

- **license**: License type (e.g., `MIT`, `Apache-2.0`)

- **tags**: Searchable tags array for organization

**Complete example frontmatter** provided showing all fields in use.

#### 2. **Critical Clarification: skill.json NOT Supported**

**Added prominent note:**
```
**Note about skill.json files:**
- Claude Code **does NOT support skill.json files** for metadata
- Only SKILL.md with YAML frontmatter is read by Claude Code
- If you create a skill.json file, it will be ignored (though harmless)
- All metadata must be in the YAML frontmatter of SKILL.md
```

**Why this matters:**
- Prevents confusion about dual metadata systems
- Clarifies official Claude Code behavior
- Based on Perplexity research confirming skill.json is not used
- Saves developers time by not creating unnecessary files

#### 3. **Enhanced init_skill.py Template**

**Updated SKILL_TEMPLATE to include all recommended metadata fields:**

**Before (v1.0.0)**:
```yaml
---
name: {skill_name}
description: [TODO...]
---
```

**After (v1.1.0)**:
```yaml
---
name: {skill_name}
description: |
  [TODO: Comprehensive guidance with third-person voice requirement]
version: 1.0.0
category: [TODO: Examples provided]
triggers:
  - {skill_name}
  - [TODO: Specific guidance for each type]
author: [TODO: Your Name]
license: MIT
tags:
  - [TODO: Common tag examples]
---
```

**Added inline TODO guidance** for each field with:
- Specific instructions
- Common examples
- Best practices
- Category suggestions

**Added explanatory note** in generated SKILL.md:
> **Note:** Only the YAML frontmatter above is required for Claude Code to discover this skill. The `name` and `description` fields are essential - all other fields are optional but recommended for documentation and organization. Claude Code does NOT support skill.json files.

#### 4. **Metadata Quality Tips**

**Added actionable guidance:**
- Make descriptions specific and action-oriented
- Include concrete use cases
- List common user phrases in triggers
- Keep frontmatter organized and properly indented (2 spaces for YAML)

### Research Foundation

These updates are based on:
1. **Real-world usage** during taskfile skill development
2. **Perplexity research** confirming Claude Code behavior:
   - skill.json files are NOT read by Claude Code
   - Only SKILL.md YAML frontmatter is used
   - `name` and `description` are required
   - All other fields are optional

### Files Updated

- `SKILL.md` - Comprehensive YAML frontmatter documentation
- `scripts/init_skill.py` - Enhanced template with all metadata fields
- `CHANGELOG.md` - This file

### Impact on Skill Creators

**Benefits:**
- ✅ Clear understanding of required vs. optional metadata fields
- ✅ Better skill discoverability through triggers and tags
- ✅ Consistent metadata across all new skills
- ✅ No wasted effort creating skill.json files
- ✅ Comprehensive examples and guidance

**Migration for existing skills:**
- No breaking changes - existing skills continue to work
- Consider adding optional fields for better organization
- Remove skill.json files if present (they're not used)

### Testing

- ✅ init_skill.py tested with new template
- ✅ Generated skill validated successfully
- ✅ All TODO prompts verified for clarity
- ✅ SKILL.md frontmatter example validated

---

## Version 1.0.0 - Initial Release

- Core skill creation guidance
- init_skill.py script for generating skill templates
- package_skill.py for validation and packaging
- Comprehensive step-by-step process documentation
- Examples and best practices
