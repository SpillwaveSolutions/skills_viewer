---
name: taskfile
description: |
  Expert-level guidance for Task (Go-based task runner) and Taskfile.yml configurations. This skill should be invoked when: (1) creating or setting up Taskfiles for new or existing projects, (2) reading Taskfiles to understand project structure, build/test/deploy workflows, and deployment architecture, (3) installing Task or configuring standardized workflows for various tech stacks (Maven, Gradle, Poetry, UV, NPM, Yarn, Docker, monorepos), (4) analyzing Taskfile structure to generate deployment diagrams using Mermaid or PlantUML, (5) troubleshooting Task execution or converting Makefiles to Taskfiles, or (6) organizing utility scripts in utils namespaces. Provides templates, best practices, and project analysis capabilities. Always runs 'task --list' first when encountering projects with Taskfiles.
version: 2.0.0
category: build-automation
triggers:
  - taskfile
  - task runner
  - Taskfile.yml
  - task --list
  - install task
  - setup task
  - create taskfile
  - task build
  - task test
  - task deploy
  - task clean
  - makefile conversion
  - convert makefile
  - monorepo orchestration
  - monorepo automation
  - build automation
  - deployment workflow
  - project structure analysis
  - CI/CD pipeline
  - task orchestration
  - nested taskfiles
  - utils namespace
  - go-task
  - task.dev
  - yaml automation
  - build script
  - test automation
  - deployment automation
  - cross-platform build
  - task dependencies
  - task includes
  - docker orchestration
  - maven automation
  - gradle automation
  - npm automation
  - python automation
author: Richard Hightower
license: MIT
tags:
  - build-automation
  - task-runner
  - yaml
  - ci-cd
  - monorepo
  - deployment
  - cross-platform
  - workflow-orchestration
  - makefile-alternative
  - go-task
---

# Taskfile Expert Skill

## Purpose

Provide expert-level assistance with Task, a modern alternative to GNU Make written in Go. Task uses YAML-based Taskfile.yml files to define and automate workflows across diverse tech stacks. This skill enables:

- **Standardizing workflows** across different project types (build, test, deploy, package)
- **Understanding projects** by reading Taskfiles as executable documentation
- **Analyzing deployment architecture** from Taskfile structure and dependencies
- **Generating diagrams** (Mermaid, PlantUML) from Taskfile analysis
- **Setting up automation** for new and existing projects
- **Monorepo orchestration** with nested Taskfiles and unified commands

## When to Use This Skill

Invoke this skill when:

1. **Installing or setting up Task** - Getting started with Task installation and configuration
2. **Creating Taskfiles** - Setting up automation for new or existing projects
3. **Understanding projects** - Reading Taskfiles to learn project structure and workflows
4. **Analyzing architecture** - Extracting deployment architecture and service dependencies
5. **Generating diagrams** - Creating visual representations of deployment flows and architecture
6. **Troubleshooting** - Debugging Task execution, dependencies, or environment issues
7. **Converting from Make** - Migrating Makefiles to Taskfiles

## Quick Start by Use Case

**Choose your path**:

| Use Case | Reference File | Quick Action |
|----------|----------------|--------------|
| Install Task | `references/installation.md` | Platform-specific installation |
| New project setup | `references/greenfield-setup.md` | Copy template, customize |
| Add to existing project | `references/existing-project-setup.md` | Analyze, map, integrate |
| Understand a project | `references/understanding-projects.md` | Run `task --list`, read Taskfile |
| Analyze deployment | `references/deployment-analysis.md` | Extract architecture patterns |
| Generate diagrams | `references/diagram-generation.md` | Create Mermaid/PlantUML |
| Troubleshoot YAML errors | `references/common-yaml-pitfalls.md` | Fix colon/syntax issues |
| Advanced features | `references/taskfile-comprehensive-guide.md` | Deep dive into Task features |

**Always start with**: `task --list` when encountering a project with a Taskfile.

## YAML Best Practices and Common Pitfalls

**CRITICAL**: Task uses YAML for configuration. Follow these guidelines to avoid parsing errors:

### Avoid Colons in String Values

**Most common error**: Colons (`:`) in echo statements or messages cause YAML parsing failures.

```yaml
# ❌ WILL FAIL
cmds:
  - echo "Error: Node.js not installed"

# ✅ WORKS - Use dash instead
cmds:
  - echo "Error - Node.js not installed"
```

**Why**: Even when double-quoted, colons confuse the YAML parser because they're used as key-value separators.

**Solutions**:
1. Replace colons with dashes `-`, commas `,`, or rephrase
2. Use YAML block scalars: `- |` for literal strings
3. Break into multiple echo statements

**Validation**: Always run `task --list` immediately after creating or modifying a Taskfile to catch syntax errors early.

**For comprehensive YAML troubleshooting**, see `references/common-yaml-pitfalls.md`.

## Standardized Task Names

This skill promotes a consistent set of task names across all project types:

### Core Development Tasks
- **build** - Compile/build the project
- **test** - Run unit tests
- **deploy** - Deploy to environment
- **package** - Create distribution artifacts
- **clean** - Remove build artifacts and temporary files
- **install** - Install project dependencies

### Testing Tasks
- **integration-test** (alias: **itest**) - Run integration tests
- **coverage** - Generate code coverage reports for unit tests
- **coverage:all** - Run all tests and generate comprehensive coverage
- **e2e** - Execute end-to-end tests
- **bench** - Run benchmarks

### Code Quality Tasks
- **lint** - Check code for style violations and errors
- **format** - Auto-format code for consistency
- **vet** - Perform static analysis
- **audit** - Scan for security vulnerabilities

### Development Tasks
- **run** - Launch the application locally
- **dev** - Start development mode with watching/hot-reload

### Release Tasks
- **release** - Prepare and tag a new release version
- **publish** - Publish artifacts to registries

### Additional Tasks
- **doc** - Generate documentation
- **migrate** - Apply database migrations
- **ci** - Simulate full CI pipeline locally
- **docker:build** - Build Docker images
- **docker:push** - Push Docker images to registry

## Understanding Projects Through Taskfiles

**CRITICAL FIRST STEP**: Always run `task --list` when encountering a project with a Taskfile. This immediately reveals all available operations and their descriptions.

### Taskfiles as Living Documentation

Taskfiles provide executable documentation showing:
- **Available operations** via `task --list`
- **Project structure** via `includes:` and namespaced tasks
- **Workflow order** via task `deps:` dependencies
- **Tech stack** via commands (mvn, npm, docker, etc.)
- **Environment needs** via `dotenv:` and `requires:`
- **Deployment architecture** via service organization and deploy tasks

### Quick Understanding Workflow

```bash
# 1. List all tasks (ALWAYS FIRST)
task --list

# 2. Read the Taskfile structure
cat Taskfile.yml | grep -E "(includes:|tasks:|desc:)"

# 3. Test core operations
task build
task test
```

**For detailed guidance**: See `references/understanding-projects.md`

## Analyzing Deployment Architecture

Taskfiles encode deployment architecture through:

1. **Service organization** - `includes:` show service topology
2. **Deployment flow** - `deploy` task dependencies show deployment order
3. **Infrastructure** - Commands reveal cloud providers (AWS, GCP, Azure, K8s)
4. **Environment strategy** - Environment-specific tasks show deployment targets
5. **Dependencies** - Task `deps:` reveal service dependencies

### Architecture Patterns Detectable from Taskfiles

- **Three-tier** - Presentation, application, data tiers in separate includes
- **Microservices** - Multiple service includes with gateway
- **Serverless** - Lambda/function deployment tasks
- **Monorepo** - Multiple subproject includes with orchestration
- **Container-based** - Docker build/push tasks

**For detailed guidance**: See `references/deployment-analysis.md`

## Generating Architecture Diagrams

This skill can analyze Taskfile structure and generate:

### Diagram Types

1. **Service dependency graph** - Shows which services depend on others
2. **Deployment flow** - Visualizes deployment sequence
3. **Architecture diagram** - Three-tier, microservices, or detected pattern
4. **Infrastructure map** - Cloud resources and services

### Integration with Diagram Skills

**If available, invoke these skills**:
- **design-doc-mermaid** - For comprehensive Mermaid diagrams in docs
- **plantuml** - For PlantUML deployment and component diagrams

### Using the Analysis Script

```bash
# Generate all diagrams
python scripts/analyze_taskfile.py Taskfile.yml

# Generate specific diagram
python scripts/analyze_taskfile.py Taskfile.yml --diagram deployment

# Export as JSON for programmatic use
python scripts/analyze_taskfile.py Taskfile.yml --format json
```

**For detailed guidance**: See `references/diagram-generation.md`

## How to Use This Skill

### 1. Installing Task

**See**: `references/installation.md` for platform-specific installation instructions.

Quick install:
```bash
# macOS
brew install go-task/tap/go-task

# Linux
sudo snap install task --classic

# Windows
scoop install task
```

### 2. Creating Taskfiles for New Projects

**See**: `references/greenfield-setup.md` for detailed setup guide.

Quick start:
1. Choose template from `assets/templates/` matching your tech stack
2. Copy to project root as `Taskfile.yml`
3. Customize project name, version, and commands
4. Test with `task --list`

Available templates: Maven, Gradle, Poetry, UV, NPM, Yarn, Docker, Docker Compose, Monorepo

### 3. Adding Task to Existing Projects

**See**: `references/existing-project-setup.md` for migration guide.

Quick workflow:
1. Analyze existing build system (Make, scripts, package.json)
2. Select appropriate template
3. Map existing commands to standardized task names
4. Test incrementally (start with build, test, clean)

### 4. Understanding Existing Projects

**See**: `references/understanding-projects.md` for detailed analysis guide.

Critical first step: `task --list`

### 5. Analyzing Deployment Architecture

**See**: `references/deployment-analysis.md` for architecture extraction patterns.

### 6. Generating Diagrams

**See**: `references/diagram-generation.md` for Mermaid/PlantUML generation.

Use: `python scripts/analyze_taskfile.py Taskfile.yml`

### 7. Monorepo Patterns

**See**: `references/taskfile-comprehensive-guide.md` section on Monorepo Setup for complete details.

Key concepts:
- **Root Taskfile** - Orchestrates all subprojects
- **`includes:`** - Imports subproject Taskfiles with namespacing
- **Utils namespace** - Organize utility scripts with `internal: true`
- **Environment inheritance** - Subprojects can inherit root .env files

Quick example:
```yaml
# Root Taskfile.yml
includes:
  backend: ./backend/Taskfile.yml
  frontend: ./frontend/Taskfile.yml

tasks:
  build:
    desc: Build all projects
    deps:
      - backend:build
      - frontend:build
```

Templates available:
- `assets/templates/Taskfile-monorepo-root.yml`
- `assets/templates/Taskfile-monorepo-subproject.yml`
- `assets/templates/Taskfile-utils.yml`

### 8. Troubleshooting

**See**: `references/taskfile-comprehensive-guide.md` Troubleshooting section for complete solutions.

Common quick fixes:
- **.env not loading**: Check `dotenv:` file order, use `task --verbose`
- **Task not found**: Check spelling, namespace (e.g., `backend:build`), or `internal: true`
- **Wrong order**: Review `deps:` configuration
- **Not re-running**: Check `sources:` / `generates:`, clear `.task/` cache

### 9. Best Practices

Quick guidelines:
- **Naming**: kebab-case, descriptive, always add `desc:`
- **Organization**: Root Taskfile + `includes:` for modularity
- **Performance**: Use `sources:` / `generates:` with `method: checksum`
- **Safety**: Add `requires:` and `preconditions:`
- **Environment**: Order `.env` files carefully (later overrides earlier)

**See**: `references/taskfile-comprehensive-guide.md` Best Practices section for detailed guidelines.

## Reference Documentation

This skill uses Progressive Disclosure Architecture - load only what you need:

### Use Case Specific References
- **`references/installation.md`** - Installing Task on all platforms
- **`references/greenfield-setup.md`** - Setting up new projects from scratch
- **`references/existing-project-setup.md`** - Adding Task to existing projects
- **`references/understanding-projects.md`** - Reading Taskfiles as documentation
- **`references/deployment-analysis.md`** - Extracting deployment architecture
- **`references/diagram-generation.md`** - Creating Mermaid/PlantUML diagrams
- **`references/common-yaml-pitfalls.md`** - YAML syntax issues and troubleshooting

### Comprehensive Reference
- **`references/taskfile-comprehensive-guide.md`** - Complete Task reference covering all features, syntax, integrations, and advanced patterns

Use `Read` to load references as needed based on the current task.

## Templates

Ready-to-use Taskfile templates are available in `assets/templates/`:

- **Taskfile-maven.yml** - Maven projects with JaCoCo coverage
- **Taskfile-gradle.yml** - Gradle projects with JaCoCo coverage
- **Taskfile-poetry.yml** - Poetry Python projects with pytest
- **Taskfile-uv.yml** - UV Python projects with pytest
- **Taskfile-npm.yml** - NPM JavaScript/TypeScript projects
- **Taskfile-yarn.yml** - Yarn JavaScript/TypeScript projects
- **Taskfile-docker.yml** - Docker image build and deployment
- **Taskfile-docker-compose.yml** - Docker Compose service orchestration
- **Taskfile-monorepo-root.yml** - Monorepo root with cross-project orchestration
- **Taskfile-monorepo-subproject.yml** - Monorepo subproject template (customizable for any tech stack)
- **Taskfile-utils.yml** - Utility scripts wrapper for organizing Bash/Python scripts in a utils namespace

Use these templates as starting points and customize them to fit specific project needs.

## Scripts and Tools

### Taskfile Analysis Script

**`scripts/analyze_taskfile.py`** - Python script for analyzing Taskfiles and generating diagrams

Capabilities:
- Extract service dependencies
- Detect architecture patterns (three-tier, microservices, monorepo, serverless)
- Identify cloud providers (AWS, GCP, Azure, Kubernetes)
- Detect tech stack (Maven, NPM, Docker, etc.)
- Generate Mermaid diagrams (service graph, deployment flow, architecture)
- Export analysis as JSON

Usage:
```bash
# Generate all diagrams
python scripts/analyze_taskfile.py Taskfile.yml

# Generate specific diagram
python scripts/analyze_taskfile.py --diagram deployment

# Export as JSON
python scripts/analyze_taskfile.py --format json
```

Requirements: `pip install pyyaml`

## Integration with Other Skills

This skill integrates with:
- **design-doc-mermaid** - Invoke for comprehensive Mermaid diagrams in design docs
- **plantuml** - Invoke for PlantUML deployment and component diagrams

When these skills are available, this skill will suggest invoking them for diagram generation.

## Summary

This skill provides expert-level assistance with Task (Taskfile.yml) for:
- **Project automation** - Standardized build, test, deploy workflows
- **Project understanding** - Reading Taskfiles as living documentation
- **Architecture analysis** - Extracting deployment architecture and dependencies
- **Diagram generation** - Creating visual representations with Mermaid/PlantUML
- **Multi-language support** - Templates for Maven, Gradle, Poetry, UV, NPM, Yarn, Docker
- **Monorepo orchestration** - Unified commands across multiple subprojects

**Key workflows**:
1. **Install**: Use platform-specific installation (brew, snap, scoop)
2. **Create**: Choose template → customize → test with `task --list`
3. **Understand**: Run `task --list` → read Taskfile structure → analyze dependencies
4. **Analyze**: Extract architecture patterns → detect cloud providers → identify services
5. **Visualize**: Generate diagrams → integrate with design-doc-mermaid or plantuml skills

**Always start with**: `task --list` when encountering a project with a Taskfile.

**Progressive Disclosure**: Use the Quick Start table and reference files to load only the information needed for your current task.
