# Generating Deployment Diagrams from Taskfiles

## Overview

Taskfiles contain structured information about deployment architecture, service dependencies, and infrastructure that can be visualized as diagrams. This guide shows how to generate Mermaid and PlantUML diagrams from Taskfile analysis.

## When to Generate Diagrams

Generate diagrams when:
1. Onboarding new team members
2. Documenting deployment architecture
3. Analyzing service dependencies
4. Planning infrastructure changes
5. Creating technical documentation
6. Explaining system architecture

## Skill Integration

### Check for Available Skills

```bash
# Check if design-doc-mermaid skill is available
# Check if plantuml skill is available
```

If these skills are available, invoke them to generate diagrams. If not, provide Mermaid/PlantUML code that can be rendered manually.

## Diagram Types from Taskfiles

### 1. Deployment Flow Diagram

Shows the sequence of deployment steps.

**From this Taskfile**:
```yaml
tasks:
  deploy:
    deps:
      - backup:database
      - infra:provision
      - database:migrate
      - backend:deploy
      - frontend:deploy
      - smoke:test
```

**Generate Mermaid**:
```mermaid
graph TD
    A[Start Deployment] --> B[Backup Database]
    B --> C[Provision Infrastructure]
    C --> D[Migrate Database]
    D --> E[Deploy Backend]
    E --> F[Deploy Frontend]
    F --> G[Run Smoke Tests]
    G --> H[Deployment Complete]
```

### 2. Service Dependency Graph

Shows which services depend on others.

**From this Taskfile**:
```yaml
tasks:
  deploy:api:
    deps:
      - deploy:database
      - deploy:redis
      - deploy:message-queue

  deploy:worker:
    deps:
      - deploy:database
      - deploy:message-queue

  deploy:frontend:
    deps:
      - deploy:api
```

**Generate Mermaid**:
```mermaid
graph LR
    DB[(Database)]
    Redis[(Redis)]
    MQ[(Message Queue)]
    API[API Service]
    Worker[Worker Service]
    Frontend[Frontend]

    DB --> API
    DB --> Worker
    Redis --> API
    MQ --> API
    MQ --> Worker
    API --> Frontend
```

### 3. Microservices Architecture

Shows service topology and communication.

**From this Taskfile**:
```yaml
includes:
  api-gateway: ./services/gateway/Taskfile.yml
  auth-service: ./services/auth/Taskfile.yml
  user-service: ./services/user/Taskfile.yml
  order-service: ./services/order/Taskfile.yml
  payment-service: ./services/payment/Taskfile.yml
```

**Generate Mermaid**:
```mermaid
graph TB
    Client[Client]
    Gateway[API Gateway]
    Auth[Auth Service]
    User[User Service]
    Order[Order Service]
    Payment[Payment Service]

    Client --> Gateway
    Gateway --> Auth
    Gateway --> User
    Gateway --> Order
    Gateway --> Payment
    Order --> Payment
```

### 4. Three-Tier Architecture

Shows layered architecture from Taskfile includes.

**From this Taskfile**:
```yaml
includes:
  # Presentation
  web: ./web/Taskfile.yml
  mobile: ./mobile/Taskfile.yml

  # Application
  api: ./api/Taskfile.yml
  business-logic: ./services/Taskfile.yml

  # Data
  database: ./database/Taskfile.yml
  cache: ./cache/Taskfile.yml
```

**Generate Mermaid**:
```mermaid
graph TB
    subgraph Presentation["Presentation Tier"]
        Web[Web App]
        Mobile[Mobile App]
    end

    subgraph Application["Application Tier"]
        API[API]
        BL[Business Logic]
    end

    subgraph Data["Data Tier"]
        DB[(Database)]
        Cache[(Cache)]
    end

    Web --> API
    Mobile --> API
    API --> BL
    BL --> DB
    BL --> Cache
```

### 5. Container Deployment

Shows container build and deployment flow.

**From this Taskfile**:
```yaml
vars:
  DOCKER_REGISTRY: gcr.io/my-project

tasks:
  docker:build:
    cmds:
      - docker build -t {{.DOCKER_REGISTRY}}/api .

  docker:push:
    deps: [docker:build]
    cmds:
      - docker push {{.DOCKER_REGISTRY}}/api

  docker:deploy:
    deps: [docker:push]
    cmds:
      - kubectl apply -f k8s/deployment.yaml
```

**Generate Mermaid**:
```mermaid
graph LR
    Code[Source Code] -->|docker build| Image[Docker Image]
    Image -->|docker push| Registry[GCR Registry]
    Registry -->|kubectl apply| K8s[Kubernetes Cluster]
```

### 6. CI/CD Pipeline

Shows continuous integration and deployment flow.

**From this Taskfile**:
```yaml
tasks:
  ci:
    desc: Run full CI pipeline
    cmds:
      - task: clean
      - task: install
      - task: lint
      - task: test
      - task: coverage
      - task: build
      - task: package

  cd:
    desc: Run CD pipeline
    deps: [ci]
    cmds:
      - task: deploy:staging
      - task: test:integration
      - task: deploy:prod
```

**Generate Mermaid**:
```mermaid
graph TD
    A[Code Commit] --> B[Clean]
    B --> C[Install Dependencies]
    C --> D[Lint Code]
    D --> E[Run Tests]
    E --> F[Coverage Check]
    F --> G[Build]
    G --> H[Package]
    H --> I{CI Passed?}
    I -->|Yes| J[Deploy to Staging]
    I -->|No| K[Fail Build]
    J --> L[Integration Tests]
    L --> M{Tests Passed?}
    M -->|Yes| N[Deploy to Production]
    M -->|No| O[Rollback]
```

## PlantUML Diagrams

### Deployment Diagram

```plantuml
@startuml
!include <C4/C4_Deployment>

Deployment_Node(web, "Web Server") {
    Container(frontend, "Frontend", "React")
}

Deployment_Node(api, "API Server") {
    Container(api_service, "API", "Node.js")
}

Deployment_Node(db, "Database Server") {
    ContainerDb(database, "Database", "PostgreSQL")
}

Rel(frontend, api_service, "Makes API calls", "HTTPS")
Rel(api_service, database, "Reads/Writes", "TCP/5432")
@enduml
```

### Component Diagram

```plantuml
@startuml
!include <C4/C4_Component>

Container_Boundary(api, "API Service") {
    Component(auth, "Auth Module")
    Component(users, "User Module")
    Component(orders, "Order Module")
}

ContainerDb(db, "Database", "PostgreSQL")
Container(cache, "Cache", "Redis")

Rel(auth, db, "Authenticates")
Rel(users, db, "CRUD Operations")
Rel(orders, db, "CRUD Operations")
Rel(orders, cache, "Caches")
@enduml
```

### Sequence Diagram

```plantuml
@startuml
actor User
participant Frontend
participant Gateway
participant Auth
participant API
database Database

User -> Frontend: Request
Frontend -> Gateway: HTTP Request
Gateway -> Auth: Verify Token
Auth --> Gateway: Token Valid
Gateway -> API: Forward Request
API -> Database: Query
Database --> API: Results
API --> Gateway: Response
Gateway --> Frontend: Response
Frontend --> User: Display
@enduml
```

## Automated Diagram Generation Script

### Python Script Structure

```python
#!/usr/bin/env python3
"""
Generate architecture diagrams from Taskfile.yml analysis.
"""

import yaml
import sys
from pathlib import Path

def analyze_taskfile(taskfile_path):
    """Analyze Taskfile and extract architecture info."""
    with open(taskfile_path) as f:
        taskfile = yaml.safe_load(f)

    includes = taskfile.get('includes', {})
    tasks = taskfile.get('tasks', {})

    return {
        'includes': includes,
        'tasks': tasks,
        'vars': taskfile.get('vars', {})
    }

def generate_service_diagram(analysis):
    """Generate Mermaid service dependency diagram."""
    includes = analysis['includes']

    mermaid = ["graph TB"]

    for name, config in includes.items():
        node_id = name.replace('-', '_')
        mermaid.append(f"    {node_id}[{name}]")

    return "\n".join(mermaid)

def generate_deployment_flow(analysis):
    """Generate Mermaid deployment flow diagram."""
    tasks = analysis['tasks']
    deploy_task = tasks.get('deploy', {})
    deps = deploy_task.get('deps', [])

    mermaid = ["graph TD"]
    mermaid.append("    Start[Start Deployment]")

    prev = "Start"
    for i, dep in enumerate(deps):
        current = f"Step{i}"
        mermaid.append(f"    {current}[{dep}]")
        mermaid.append(f"    {prev} --> {current}")
        prev = current

    mermaid.append(f"    {prev} --> End[Complete]")

    return "\n".join(mermaid)

if __name__ == '__main__':
    taskfile_path = sys.argv[1] if len(sys.argv) > 1 else 'Taskfile.yml'
    analysis = analyze_taskfile(taskfile_path)

    print("# Service Architecture")
    print("```mermaid")
    print(generate_service_diagram(analysis))
    print("```")

    print("\n# Deployment Flow")
    print("```mermaid")
    print(generate_deployment_flow(analysis))
    print("```")
```

## Integration with Skills

### Using design-doc-mermaid Skill

If the design-doc-mermaid skill is available:

```yaml
tasks:
  docs:architecture:
    desc: Generate architecture documentation with diagrams
    cmds:
      - task: analyze:taskfile
      - # Invoke design-doc-mermaid skill with analysis
```

### Using plantuml Skill

If the plantuml skill is available:

```yaml
tasks:
  diagrams:generate:
    desc: Generate PlantUML diagrams
    cmds:
      - task: analyze:taskfile
      - # Invoke plantuml skill with generated .puml files
```

## Manual Diagram Creation

If skills are not available, provide the Mermaid/PlantUML code for manual rendering:

1. Copy the generated Mermaid code
2. Paste into:
   - GitHub markdown (renders automatically)
   - https://mermaid.live (online editor)
   - VS Code with Mermaid extension
3. Or copy PlantUML code to:
   - https://www.plantuml.com/plantuml
   - VS Code with PlantUML extension

## Best Practices

1. **Keep diagrams focused**: Don't try to show everything in one diagram
2. **Use subgraphs**: Group related services for clarity
3. **Show data flow**: Use arrows to indicate direction
4. **Label relationships**: Add text to arrows explaining the relationship
5. **Update regularly**: Regenerate diagrams when Taskfiles change
6. **Version control**: Commit generated diagrams alongside code

## Example: Complete Analysis Workflow

```bash
# Step 1: Analyze Taskfile
task analyze:architecture

# Step 2: Generate service dependency diagram
task diagrams:services

# Step 3: Generate deployment flow diagram
task diagrams:deployment

# Step 4: Generate three-tier architecture diagram
task diagrams:layers

# Step 5: Export all diagrams
task diagrams:export-all
```

## Next Steps

- **Understanding projects**: See `references/understanding-projects.md`
- **Deployment analysis**: See `references/deployment-analysis.md`
- **Script reference**: See `scripts/analyze_taskfile.py`
- **Mermaid syntax**: See https://mermaid.js.org/
- **PlantUML syntax**: See https://plantuml.com/
