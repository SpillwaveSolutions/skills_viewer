# Common YAML Pitfalls in Taskfiles

This reference document covers common YAML syntax issues encountered when creating Taskfiles, with practical solutions and best practices.

## Overview

Task uses YAML for its configuration files, and while YAML is generally forgiving, certain patterns can cause parsing errors that prevent Taskfiles from loading. This guide helps avoid and fix these issues.

## Critical Issue: Colons in String Values

### The Problem

**Most Common Error**: Colons (`:`) inside string values, even when double-quoted, can cause YAML parsing errors in Task.

**Why It Happens**:
- YAML uses colons as key-value separators
- The YAML parser scans ahead and may get confused by patterns like `"text: more text"`
- Task's YAML library may be stricter than other YAML processors

### Examples of Problematic Code

```yaml
# ❌ WILL FAIL - Colon in echo string
format:frontend:
  desc: Format frontend code
  cmds:
    - echo "Error: Prettier not configured"

# ❌ WILL FAIL - Colon in informational message
outdated:
  desc: Check dependencies
  cmds:
    - cargo outdated || echo "Install tool: cargo install cargo-outdated"

# ❌ WILL FAIL - Colon in error message
verify:
  cmds:
    - command -v node || echo "Error: Node.js not installed"
```

### Error Message

When this occurs, you'll see:

```
invalid keys in command
file: Taskfile.yml:145:9
  143 |     desc: "..."
  144 |     cmds:
> 145 |       - echo "Error: Something went wrong"
      |         ^
```

### Solutions

**Solution 1: Remove or Replace Colons**

```yaml
# ✅ WORKS - Use dash instead
cmds:
  - echo "Error - Prettier not configured"

# ✅ WORKS - Use comma
cmds:
  - echo "Error, Prettier not configured"

# ✅ WORKS - Rephrase without punctuation
cmds:
  - echo "Error with Prettier configuration"

# ✅ WORKS - Use word "to"
cmds:
  - echo "Install cargo-outdated with cargo install cargo-outdated"
```

**Solution 2: Use Single Quotes (Sometimes)**

```yaml
# ✅ MAY WORK - Single quotes can be more forgiving
cmds:
  - echo 'Error: Something went wrong'
```

Note: This doesn't always work depending on the YAML parser version. Best to avoid colons entirely.

**Solution 3: Break Into Multiple Commands**

```yaml
# ✅ WORKS - Separate echo statements
cmds:
  - echo "To install cargo-outdated, run the following command"
  - echo "cargo install cargo-outdated"
```

**Solution 4: Use printf Instead of echo**

```yaml
# ✅ WORKS - printf with format string
cmds:
  - printf "Install cargo-outdated with: %s\n" "cargo install cargo-outdated"
```

**Solution 5: Use YAML Block Scalars**

```yaml
# ✅ WORKS - Use literal block scalar (|)
cmds:
  - |
    echo "Error: Something went wrong"

# ✅ WORKS - Use folded block scalar (>)
cmds:
  - >
    echo "Error: Something went wrong"
```

### Best Practices for Avoiding Colon Issues

1. **Scan all echo/printf statements** for colons before running `task --list`
2. **Prefer alternative punctuation**: dashes (-), commas (,), semicolons (;)
3. **Rephrase messages** to avoid needing colons
4. **Use block scalars** for complex multi-line strings
5. **Test immediately** with `task --list` after creating Taskfile

## Other Common YAML Issues

### Issue: Improper String Quoting

```yaml
# ❌ FAILS - Special characters not quoted
desc: This & that

# ✅ WORKS - Quote strings with special characters
desc: "This & that"
```

**Characters requiring quotes**: `& * ? | - { } [ ] , > @ ! % : #`

### Issue: Inconsistent Indentation

```yaml
# ❌ FAILS - Mixed tabs and spaces
tasks:
  build:
    desc: Build project
      cmds:  # Wrong indentation
      - go build

# ✅ WORKS - Consistent 2-space indentation
tasks:
  build:
    desc: Build project
    cmds:
      - go build
```

**Best Practice**: Always use 2 spaces for indentation, never tabs.

### Issue: Multi-line Strings Without Block Scalars

```yaml
# ❌ PROBLEMATIC - Long string on single line
desc: "This is a very long description that goes on and on and is hard to read and maintain"

# ✅ BETTER - Use folded scalar (>)
desc: >
  This is a very long description
  that spans multiple lines
  for better readability

# ✅ ALSO GOOD - Use literal scalar (|) to preserve newlines
desc: |
  This is a description
  with preserved line breaks
  for formatted output
```

### Issue: Boolean Values Without Quotes

```yaml
# ⚠️ CAUTION - These are parsed as booleans, not strings
value: true   # Boolean true
value: false  # Boolean false
value: yes    # Boolean true
value: no     # Boolean false

# ✅ CORRECT - Quote if you want strings
value: "true"   # String "true"
value: "false"  # String "false"
value: "yes"    # String "yes"
value: "no"     # String "no"
```

### Issue: Unquoted Leading/Trailing Whitespace

```yaml
# ❌ LOSES WHITESPACE
desc:   Leading spaces

# ✅ PRESERVES WHITESPACE
desc: "  Leading spaces"
```

## Validation Checklist

Before using a generated or modified Taskfile:

- [ ] Run `task --list` to verify syntax
- [ ] Search for all echo/printf statements containing colons
- [ ] Verify all variables are properly quoted: `"{{.VAR}}"`
- [ ] Check indentation is consistent (2 spaces, no tabs)
- [ ] Test with `task --dry <task-name>` to preview execution
- [ ] Ensure file paths use forward slashes (even on Windows)
- [ ] Verify no unquoted special characters in strings

## Quick Fixes for Common Errors

### Error: "invalid keys in command"

**Most likely cause**: Colon in a string value (especially echo statements)

**Fix**: Search the line number in error message for colons in strings and remove/replace them.

### Error: "yaml: line X: found character that cannot start any token"

**Most likely cause**: Special character not quoted

**Fix**: Quote the string containing special characters.

### Error: "yaml: line X: mapping values are not allowed in this context"

**Most likely cause**: Colon in unquoted string or indentation issue

**Fix**: Check for unquoted colons and verify indentation.

## Testing Your Taskfile

Always test Taskfiles incrementally:

```bash
# 1. Verify syntax
task --list

# 2. Dry-run a task (shows what would execute)
task --dry build

# 3. Run with verbose output
task --verbose build

# 4. Check for YAML issues programmatically (optional)
yamllint Taskfile.yml  # Requires yamllint tool
```

## Additional Resources

- [YAML Specification](https://yaml.org/spec/)
- [Task Documentation](https://taskfile.dev/)
- [YAML Lint Tool](https://yamllint.readthedocs.io/)

## Summary

**Key Takeaway**: Avoid colons in string values within Taskfiles. When you must include colons, use block scalars (`|` or `>`), or better yet, rephrase the message.

**Common Pattern**:
```yaml
# ❌ Don't do this
- echo "Error: Problem occurred"

# ✅ Do this instead
- echo "Error - Problem occurred"
```

This simple change prevents the majority of YAML parsing errors in Taskfiles.
