# Comprehensive Guide to Taskfile.yml

## Overview

Task is a modern alternative to GNU Make, written in Go, that uses YAML configuration files to automate workflows. It emphasizes simplicity, readability, and features like parallel execution, making it suitable for standardizing processes across projects.

## Installation Methods

Task offers multiple installation options. Always pin a specific version (e.g., v3.38 or higher) for consistency.

### Official Package Managers
- **Homebrew (macOS)**: `brew install go-task`
- **Scoop (Windows)**: `scoop install task`
- **Snap (Linux)**: `snap install task --classic`

### Other Methods
- **Binary Download**: Download from GitHub releases and add to PATH
- **Go Install**: `go install github.com/go-task/task/v3/cmd/task@latest`
- **CI/CD Integration**: Use GitHub Actions setup-task or similar for pipelines

After installation, verify with `task --version`.

## Basic Taskfile Structure

All Taskfiles start with a version declaration:

```yaml
version: '3'
```

### Key Top-Level Sections

- **tasks**: Defines individual tasks
- **env**: Global environment variables
- **dotenv**: Array of .env files to load (e.g., `['.env', '.env.local']`)
- **includes**: For modularizing by importing other Taskfiles
- **vars**: Global variables (can be dynamic with `sh:`)
- **set**: Shell options (e.g., `[pipefail]` for robust pipelines)

### Minimal Example

```yaml
version: '3'
dotenv: ['.env']
tasks:
  default:
    cmds:
      - task --list
```

## Defining Tasks

Each task under `tasks:` can have:

- **desc**: Short description (shown in `task --list`)
- **summary**: Longer description with details
- **cmds**: Array of commands to run
- **deps**: Dependencies to execute first (parallel by default)
- **env**: Task-specific environment variables
- **dir**: Working directory
- **sources**: Files to check for changes (for up-to-date checks)
- **generates**: Output files to check (for up-to-date checks)
- **preconditions**: Conditions to check before running
- **requires**: Mandatory variables that must be set
- **run**: Controls execution (`always`, `once`, `when_changed`)
- **silent**: Suppress output (true/false)
- **internal**: Hide from task list (true/false)
- **platforms**: Restrict to specific platforms
- **aliases**: Alternative names for the task
- **method**: For up-to-date checks (`checksum` or `timestamp`)

## Standardized Task Names

### Core Development Tasks

- **build**: Compile/build the project
- **test**: Run unit tests
- **deploy**: Deploy to environment
- **package**: Create distribution artifacts
- **clean**: Remove build artifacts and temporary files
- **install**: Install project dependencies

### Testing Tasks

- **integration-test** (or **itest**): Run integration tests
- **coverage**: Generate code coverage reports for unit tests
- **coverage:all**: Run all tests and generate comprehensive coverage
- **e2e**: Execute end-to-end tests
- **bench**: Run benchmarks

### Code Quality Tasks

- **lint**: Check code for style violations and errors
- **format**: Auto-format code for consistency
- **vet**: Perform static analysis
- **audit**: Scan for security vulnerabilities

### Development Tasks

- **run**: Launch the application locally
- **dev**: Start development mode with watching/hot-reload

### Release Tasks

- **release**: Prepare and tag a new release version
- **publish**: Publish artifacts to registries

### Documentation & Database Tasks

- **doc**: Generate documentation
- **migrate**: Apply database migrations

### CI/CD Tasks

- **ci**: Simulate full CI pipeline locally

### Container Tasks

- **docker:build**: Build Docker images
- **docker:push**: Push Docker images to registry
- **docker:run**: Run Docker containers

## Task Dependencies

Dependencies ensure sequential or parallel execution. Use `deps:` to list tasks:

```yaml
tasks:
  assets:
    deps: [js, css]  # Runs js and css in parallel
  js:
    cmds: [esbuild js/index.js]
  css:
    cmds: [esbuild css/index.css]
```

Dependencies run in parallel by default. For sequential execution, chain with command operators (&&) or use deps with careful ordering.

## Environment Variables and .env Files

Task supports global/task-level `env`, with expansion from shell commands.

### Loading .env Files

```yaml
dotenv: ['.env', '.env.local', '{{.ENV}}/.env']
```

- Multiple files can be loaded
- Later files override earlier ones
- Task-level `dotenv` overrides global settings
- Variables from CLI (e.g., `ENV=prod task deploy`) override all

### Example

```yaml
version: '3'
dotenv: ['.env', '.env.local']
env:
  GREETING: "Hello from {{sh 'date +%H'}}"
tasks:
  greet:
    cmds:
      - echo $GREETING
```

## Variables

### Static Variables

```yaml
vars:
  PROJECT_NAME: myapp
  VERSION: 1.0.0
```

### Dynamic Variables

```yaml
vars:
  GIT_COMMIT:
    sh: git log -n 1 --format=%h
  BUILD_TIME:
    sh: date -u +%Y-%m-%dT%H:%M:%SZ
```

Use variables with `{{.VARIABLE_NAME}}` syntax.

## Up-to-Date Checks

Prevent unnecessary task execution by tracking source files and generated outputs:

```yaml
tasks:
  build:
    desc: Build the project
    sources:
      - 'src/**/*.go'
      - 'go.mod'
      - 'go.sum'
    generates:
      - 'bin/app'
    cmds:
      - go build -o bin/app
    method: checksum  # or timestamp
```

Task skips execution if sources haven't changed since generates were created.

## Includes for Modular Taskfiles

Split large Taskfiles into modules:

```yaml
version: '3'
includes:
  docker: ./tasks/docker.yml
  backend: ./backend/Taskfile.yml
  frontend:
    taskfile: ./frontend/Taskfile.yml
    dir: ./frontend
    vars:
      BUILD_ENV: production
```

Call included tasks with namespace: `task docker:build` or `task backend:test`.

## Monorepo Patterns

### Overview

In monorepos with multiple projects, Task's `includes` feature enables modular organization. Nesting Taskfiles with includes and namespaces keeps the root file concise while allowing root-level commands to orchestrate sub-tasks across projects.

### Recommended Directory Structure

```
monorepo/
├── Taskfile.yml                  # Root orchestration
├── rust-backend/
│   ├── Taskfile.yml              # Rust-specific tasks
│   └── src/
├── node-frontend/
│   ├── Taskfile.yml              # Node-specific tasks
│   └── src/
├── java-middleware/
│   ├── Taskfile.yml              # Java-specific tasks
│   └── src/
├── scripts/
│   └── utils/
│       ├── Taskfile.yml          # Utility scripts wrapper
│       ├── deploy_prod.sh
│       └── backup_db.sh
├── .env                          # Global environment
└── .task/                        # Cache (gitignore)
```

### Root Taskfile with Advanced Includes

```yaml
version: '3'

dotenv: ['.env', '.env.local']

includes:
  rust-backend:
    taskfile: ./rust-backend/Taskfile.yml
    dir: ./rust-backend              # Critical: run tasks in subproject dir
    optional: false                   # Fail if Taskfile missing
    aliases: [rb]                     # Shortcut: task rb:build
    vars:                             # Pass variables to subproject
      BUILD_MODE: release

  node-frontend:
    taskfile: ./node-frontend/Taskfile.yml
    dir: ./node-frontend

  java-middleware:
    taskfile: ./java-middleware/Taskfile.yml
    dir: ./java-middleware

  utils:
    taskfile: ./scripts/utils/Taskfile.yml
    dir: ./scripts/utils
    internal: true                    # Hide from task --list

tasks:
  default:
    desc: List all available tasks
    cmds:
      - task --list

  build:
    desc: Build all projects
    deps:
      - rust-backend:build
      - node-frontend:build
      - java-middleware:build

  test:
    desc: Test all projects
    deps: [build]
    cmds:
      - task rust-backend:test
      - task node-frontend:test
      - task java-middleware:test

  cover-all:
    desc: Run coverage for all projects
    deps:
      - rust-backend:coverage
      - node-frontend:coverage
      - java-middleware:coverage

  package:
    desc: Package all projects
    deps: [test]
    cmds:
      - task rust-backend:package
      - task node-frontend:package
      - task java-middleware:package

  deploy:
    desc: Deploy all services
    deps: [package]
    requires:
      vars: [ENV]
    cmds:
      - task utils:deploy-prod
```

### Advanced Include Options

```yaml
includes:
  backend:
    taskfile: ./backend/Taskfile.yml
    dir: ./backend
    optional: true              # Don't fail if missing
    internal: false             # Show in task --list (default)
    aliases: [be, back]         # Multiple aliases
    vars:                       # Pass custom variables
      BUILD_ENV: production
      VERSION: '2.0.0'
    flatten: false              # Keep namespace (default)

  # Platform-specific includes
  docker:
    taskfile: ./docker/Taskfile_{{OS}}.yml    # OS-specific: linux, darwin, windows

  # Flattened includes (use carefully)
  shared:
    taskfile: ./shared/Taskfile.yml
    flatten: true               # Merge tasks into root namespace
```

**Key Options**:
- **`dir:`** - Sets working directory for all tasks in the included file (critical for subprojects)
- **`optional:`** - Continues if Taskfile doesn't exist (useful during setup)
- **`internal:`** - Hides namespace from `task --list` (good for utilities)
- **`aliases:`** - Creates shortcuts for long namespace names
- **`vars:`** - Passes variables to customize included Taskfile
- **`flatten:`** - Merges tasks into root (avoid for subprojects; use for shared utilities)

### Subproject Taskfile Pattern

```yaml
# rust-backend/Taskfile.yml
version: '3'

dotenv:
  - ../.env          # Inherit from root
  - .env.local       # Local overrides

vars:
  PROJECT_NAME: rust-backend
  VERSION:
    sh: cargo metadata --format-version 1 | jq -r '.packages[0].version'

tasks:
  default:
    desc: List available tasks
    cmds:
      - task --list

  install:
    desc: Install dependencies
    cmds:
      - cargo fetch

  build:
    desc: Build Rust backend
    deps: [install]
    sources: ['src/**/*.rs', 'Cargo.toml', 'Cargo.lock']
    generates: ['target/debug/{{.PROJECT_NAME}}']
    cmds:
      - cargo build
    method: checksum

  test:
    desc: Run unit tests
    deps: [build]
    cmds:
      - cargo test

  coverage:
    desc: Generate coverage report
    deps: [test]
    cmds:
      - cargo tarpaulin --out Lcov

  package:
    desc: Build release binary
    deps: [test]
    cmds:
      - cargo build --release

  deploy:
    desc: Deploy backend service
    deps: [package]
    requires:
      vars: [ENV]
    cmds:
      - echo "Deploying {{.PROJECT_NAME}} to {{.ENV}}"
```

### Utils Namespace for Script Organization

Organize Bash/Python scripts in a dedicated folder and wrap them in a utils namespace Taskfile:

```yaml
# scripts/utils/Taskfile.yml
version: '3'

dotenv:
  - ../../.env       # Inherit from root

vars:
  SCRIPTS_DIR: '..'  # Parent dir where scripts live

tasks:
  default:
    desc: List utility tasks
    cmds:
      - task --list

  deploy-prod:
    desc: Deploy to production
    requires:
      vars: [GCP_PROJECT_ID, ENV]
    preconditions:
      - test -f ../../.env.prod
    cmds:
      - bash {{.SCRIPTS_DIR}}/deploy_prod.sh {{.ENV}}

  backup-db:
    desc: Backup database
    requires:
      vars: [DB_NAME]
    cmds:
      - bash {{.SCRIPTS_DIR}}/backup_db.sh {{.DB_NAME}}

  login-gh:
    desc: Login to GitHub CLI
    cmds:
      - python {{.SCRIPTS_DIR}}/login_gh.py
```

**Benefits**:
- Centralizes scattered scripts
- Adds Task features (deps, preconditions, vars)
- Makes scripts discoverable: `task utils:deploy-prod`
- Hides complexity with `internal: true` in root

### Invoking Monorepo Tasks

```bash
# Orchestration tasks (run from root)
task build                    # Build all subprojects
task test                     # Test all subprojects
task cover-all                # Coverage across all projects
task package                  # Package all projects

# Subproject-specific tasks
task rust-backend:build       # Build only Rust backend
task node-frontend:test       # Test only Node frontend
task java-middleware:coverage # Coverage for Java middleware

# With aliases
task rb:build                 # If alias rb configured

# Utility scripts
task utils:deploy-prod ENV=staging
task utils:backup-db DB_NAME=main
```

### Best Practices for Monorepo Nesting

**Keep Root Minimal**:
- Root Taskfile orchestrates; subprojects implement
- Delegate all specific logic to subproject Taskfiles
- Use clear `desc:` fields on orchestration tasks

**Environment Variable Handling**:
- Load global .env in root
- Subprojects inherit with `../.env` and can override with local .env
- Order matters: later files override earlier ones

**Avoid Deep Nesting**:
- Task doesn't support multi-level includes
- Keep hierarchy flat: root → subprojects/utils
- Included Taskfiles cannot include others
- For complex cases, manually delegate in intermediate files

**Optimize with Caching**:
- Use `sources:`/`generates:` in subproject tasks
- Task caches per-namespace
- Example:
  ```yaml
  build:
    sources: ['src/**/*.rs']
    generates: ['target/debug/app']
    method: checksum
    cmds: [cargo build]
  ```

**Variable Propagation**:
- Variables don't auto-propagate to includes
- Explicitly pass with `vars:` in include config
- Or use `dotenv:` for global environment sharing

**Internal Flag Usage**:
- Mark utility namespaces `internal: true` to declutter
- Keep subproject namespaces visible

### Limitations and Workarounds

**Multi-Level Includes Not Supported**:
- Included files cannot include others
- Workaround: Manually call tasks in intermediate files
- Or flatten structure to avoid deep nesting

**Flatten vs Namespace Trade-offs**:
- `flatten: true` merges tasks (risks name conflicts)
- `flatten: false` (default) keeps namespaces (recommended)
- Use flatten judiciously for truly shared utilities

**Testing Variable/Directory Context**:
- Always test with `task --dry` first
- Verify working directory with `pwd` in commands
- Use `task --verbose` to debug variable expansion

## Tool-Specific Integrations

### Maven (Java)

```yaml
tasks:
  build:
    cmds: [mvn package]
  test:
    deps: [build]
    cmds: [mvn test]
  integration-test:
    deps: [build]
    cmds: [mvn integration-test]
  coverage:
    cmds: [mvn jacoco:report]
  deploy:
    dotenv: ['.env.gcp']
    cmds: [mvn deploy]
```

### Gradle (Java/Android)

```yaml
tasks:
  build:
    cmds: ['./gradlew build']
  test:
    deps: [build]
    cmds: ['./gradlew test']
  integration-test:
    cmds: ['./gradlew integrationTest']
  coverage:
    cmds: ['./gradlew jacocoTestReport']
```

### Poetry (Python)

```yaml
tasks:
  install:
    cmds: [poetry install]
  build:
    cmds: [poetry build]
  test:
    cmds: [poetry run pytest]
  coverage:
    cmds: [poetry run pytest --cov]
  lint:
    cmds: [poetry run ruff check .]
  format:
    cmds: [poetry run black .]
  deploy:
    cmds: [poetry publish]
```

### UV (Python)

```yaml
tasks:
  install:
    cmds: [uv pip install -r requirements.txt]
  build:
    cmds: [uv pip compile pyproject.toml]
  test:
    cmds: [uv run pytest]
  coverage:
    cmds: [uv run pytest --cov]
```

### NPM (JavaScript)

```yaml
tasks:
  install:
    cmds: [npm install]
  build:
    cmds: [npm run build]
  test:
    cmds: [npm test]
  coverage:
    cmds: [npm run coverage]
  lint:
    cmds: [npm run lint]
  format:
    cmds: [npm run format]
  dev:
    cmds: [npm run dev]
```

### Yarn (JavaScript)

```yaml
tasks:
  install:
    cmds: [yarn install]
  build:
    cmds: [yarn build]
  test:
    cmds: [yarn test]
  coverage:
    cmds: [yarn coverage]
  lint:
    cmds: [yarn lint]
  format:
    cmds: [yarn format]
  dev:
    cmds: [yarn dev]
```

### Docker

```yaml
tasks:
  docker:build:
    desc: Build Docker image
    cmds:
      - docker build -t {{.IMAGE_NAME}}:{{.VERSION}} .

  docker:push:
    desc: Push Docker image
    deps: [docker:build]
    cmds:
      - docker push {{.IMAGE_NAME}}:{{.VERSION}}

  docker:run:
    desc: Run Docker container
    cmds:
      - docker run -p 8080:8080 {{.IMAGE_NAME}}:{{.VERSION}}
```

### Docker Compose

```yaml
tasks:
  compose:up:
    desc: Start all services
    cmds:
      - docker-compose up -d

  compose:down:
    desc: Stop all services
    cmds:
      - docker-compose down

  compose:logs:
    desc: View service logs
    cmds:
      - docker-compose logs -f

  compose:build:
    desc: Build all services
    cmds:
      - docker-compose build
```

### GCP Deployments

```yaml
tasks:
  deploy:
    deps: [build]
    dotenv: ['.env.gcp']
    cmds:
      - gcloud app deploy
      - terraform apply  # If using Terraform
```

## Best Practices

### Naming Conventions
- Use **kebab-case** for task names (e.g., `integration-test`)
- Use **namespacing** with colons for grouping (e.g., `docker:build`)
- Always include `desc:` fields for documentation

### File Organization
- Keep SKILL.md lean; use reference files for detailed info
- Use `includes:` for modularity in large projects
- Place subdirectory Taskfiles for project-specific overrides
- Add `.task/` to `.gitignore`

### Performance Optimization
- Use `sources`/`generates` for up-to-date checks
- Set `method: checksum` for accurate change detection
- Enable parallel execution with `deps` (default behavior)
- Use `output: group` for cleaner CI logs

### Validation and Safety
- Use `requires` for mandatory variables
- Add `preconditions` for setup checks (e.g., file existence)
- Set `set: [pipefail]` globally for robust error handling
- Use `platforms` to restrict tasks to specific OS

### Development Workflow
- Mark utility tasks as `internal: true` to hide from lists
- Use `watch: true` with `sources` for live reloading
- Test with `--dry` for previews
- Use `aliases` for common shortcuts

### Environment Management
- Order `.env` files carefully (later overrides earlier)
- Use variables like `{{.ENV}}` for environment-specific configs
- Integrate with Direnv for automatic loading
- Store secrets in .env files (never commit them)

## Advanced Features

### Looping

```yaml
tasks:
  test-all:
    cmds:
      - for: { var: SERVICES }
        cmd: task test SERVICE={{.ITEM}}
    vars:
      SERVICES: [api, web, worker]
```

### Defer for Cleanup

```yaml
tasks:
  test:
    cmds:
      - docker-compose up -d
      - defer: { cmds: [docker-compose down] }
      - pytest
```

### Watch Mode

```yaml
tasks:
  dev:
    watch: true
    sources:
      - 'src/**/*.ts'
    cmds:
      - npm run build
```

### Output Capture

```yaml
tasks:
  get-version:
    cmds:
      - cmd: git describe --tags
        set: VERSION
    generates:
      - version.txt
```

### Global Taskfiles

Run tasks from anywhere with `task -g <task-name>`. Place Taskfile in `~/.taskfiles/` or configure location.

## Troubleshooting Tips

### YAML Parsing Errors with Colons

**Symptom**: `invalid keys in command` error pointing to a `cmds:` line

**Cause**: Colons (`:`) inside string values (especially in echo/printf statements) can confuse the YAML parser, even when the string is double-quoted.

**Example of problematic code**:
```yaml
# ❌ This will fail
verify:
  cmds:
    - echo "Error: Node.js not installed"
```

**Solutions**:

1. **Remove or replace colons** (recommended):
```yaml
# ✅ Use dash
- echo "Error - Node.js not installed"

# ✅ Use comma
- echo "Error, Node.js not installed"

# ✅ Rephrase
- echo "Error with Node.js installation"
```

2. **Use block scalars**:
```yaml
# ✅ Literal block scalar
cmds:
  - |
    echo "Error: Node.js not installed"
```

3. **Break into multiple commands**:
```yaml
# ✅ Separate statements
cmds:
  - echo "Error occurred"
  - echo "Node.js not installed"
```

**Prevention**: Always run `task --list` immediately after creating or modifying a Taskfile to catch YAML syntax errors early.

**For detailed YAML troubleshooting**, see `references/common-yaml-pitfalls.md`.

### General Troubleshooting

- If .env vars aren't loading, check file order and use `task --verbose`
- For large projects, split into includes to avoid monolithic files
- Test cross-platform compatibility with `platforms`
- Use `task --list` to verify task visibility
- Check task dependencies with `task --list-all`
- Debug with `task --dry` to see commands without executing
- Clear Task cache if stale: `rm -rf .task/`

## CI/CD Integration

### GitHub Actions Example

```yaml
- name: Install Task
  uses: arduino/setup-task@v1
  with:
    version: 3.x

- name: Run CI tasks
  run: task ci
```

### GitLab CI Example

```yaml
before_script:
  - sh -c "$(curl -fsSL https://taskfile.dev/install.sh)"

build:
  script:
    - task build test
```

## Key Resources

- [Official Documentation](https://taskfile.dev/)
- [Task on GitHub](https://github.com/go-task/task)
- [Style Guide](https://taskfile.dev/docs/styleguide)
- [Community Examples](https://github.com/go-task/task/discussions)
