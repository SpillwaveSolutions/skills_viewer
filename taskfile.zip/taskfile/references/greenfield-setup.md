# Setting Up Task for New (Greenfield) Projects

## Overview

This guide covers creating Taskfiles for brand new projects from scratch. Task helps standardize your workflow from day one.

## Quick Start

### 1. Choose Your Tech Stack Template

Select the appropriate template from `assets/templates/`:

```bash
# List available templates
ls ~/.claude/skills/taskfile/assets/templates/

# Copy the right template for your project
cp ~/.claude/skills/taskfile/assets/templates/Taskfile-<stack>.yml ./Taskfile.yml
```

### 2. Customize for Your Project

Edit the Taskfile to match your project needs:

```yaml
version: '3'

vars:
  PROJECT_NAME: my-new-app        # Update project name
  VERSION: '0.1.0'                # Set initial version

tasks:
  default:
    desc: List all available tasks
    cmds:
      - task --list

  install:
    desc: Install project dependencies
    cmds:
      - # Add your install command

  build:
    desc: Build the project
    deps: [install]
    cmds:
      - # Add your build command

  test:
    desc: Run unit tests
    deps: [build]
    cmds:
      - # Add your test command
```

### 3. Test Your Taskfile

```bash
# List tasks
task --list

# Run tasks
task install
task build
task test
```

## Tech Stack Specific Setup

### Python Project (UV)

```yaml
version: '3'

dotenv: ['.env', '.env.local']

vars:
  PROJECT_NAME: my-python-app
  PYTHON_VERSION: '3.11'

tasks:
  install:
    desc: Create venv and install dependencies
    cmds:
      - uv venv
      - uv pip install -e ".[dev]"
    sources:
      - pyproject.toml
      - uv.lock
    generates:
      - .venv/**

  build:
    desc: Build the project
    deps: [install]
    cmds:
      - uv build

  test:
    desc: Run tests with pytest
    deps: [install]
    cmds:
      - uv run pytest tests/ -v --cov={{.PROJECT_NAME}}

  lint:
    desc: Lint code with ruff
    cmds:
      - uv run ruff check .

  format:
    desc: Format code with ruff
    cmds:
      - uv run ruff format .

  clean:
    desc: Remove build artifacts
    cmds:
      - rm -rf dist/ build/ .pytest_cache/ .coverage htmlcov/
      - find . -type d -name "__pycache__" -exec rm -rf {} +
```

### Node.js Project (NPM)

```yaml
version: '3'

dotenv: ['.env', '.env.local']

vars:
  PROJECT_NAME: my-node-app
  NODE_VERSION: '20'

tasks:
  install:
    desc: Install dependencies
    cmds:
      - npm install
    sources:
      - package.json
      - package-lock.json
    generates:
      - node_modules/**

  build:
    desc: Build TypeScript
    deps: [install]
    cmds:
      - npm run build
    sources:
      - 'src/**/*.ts'
    generates:
      - 'dist/**/*.js'

  test:
    desc: Run tests with Jest
    deps: [build]
    cmds:
      - npm test

  lint:
    desc: Lint with ESLint
    cmds:
      - npm run lint

  format:
    desc: Format with Prettier
    cmds:
      - npm run format

  dev:
    desc: Start development server
    deps: [install]
    cmds:
      - npm run dev

  clean:
    desc: Remove build artifacts
    cmds:
      - rm -rf dist/ coverage/ .next/ node_modules/.cache/
```

### Java Project (Maven)

```yaml
version: '3'

dotenv: ['.env']

vars:
  PROJECT_NAME: my-java-app
  VERSION:
    sh: mvn help:evaluate -Dexpression=project.version -q -DforceStdout

tasks:
  clean:
    desc: Remove build artifacts
    cmds:
      - mvn clean

  install:
    desc: Install dependencies
    cmds:
      - mvn install -DskipTests

  build:
    desc: Compile the project
    deps: [clean]
    cmds:
      - mvn compile
    sources:
      - 'src/**/*.java'
      - pom.xml
    generates:
      - 'target/classes/**'

  test:
    desc: Run unit tests
    deps: [build]
    cmds:
      - mvn test

  coverage:
    desc: Generate coverage report with JaCoCo
    deps: [test]
    cmds:
      - mvn jacoco:report

  package:
    desc: Create JAR artifact
    deps: [test]
    cmds:
      - mvn package

  run:
    desc: Run the application
    deps: [build]
    cmds:
      - mvn exec:java -Dexec.mainClass="com.example.Main"
```

### Docker Project

```yaml
version: '3'

dotenv: ['.env']

vars:
  IMAGE_NAME: my-app
  IMAGE_TAG: latest
  REGISTRY: docker.io/myuser

tasks:
  docker:build:
    desc: Build Docker image
    cmds:
      - docker build -t {{.IMAGE_NAME}}:{{.IMAGE_TAG}} .
    sources:
      - Dockerfile
      - 'src/**'
    generates:
      - .docker-build-cache

  docker:run:
    desc: Run Docker container locally
    deps: [docker:build]
    cmds:
      - docker run -it --rm -p 8080:8080 {{.IMAGE_NAME}}:{{.IMAGE_TAG}}

  docker:push:
    desc: Push image to registry
    deps: [docker:build]
    cmds:
      - docker tag {{.IMAGE_NAME}}:{{.IMAGE_TAG}} {{.REGISTRY}}/{{.IMAGE_NAME}}:{{.IMAGE_TAG}}
      - docker push {{.REGISTRY}}/{{.IMAGE_NAME}}:{{.IMAGE_TAG}}

  docker:clean:
    desc: Remove Docker images and containers
    cmds:
      - docker rmi {{.IMAGE_NAME}}:{{.IMAGE_TAG}} || true
```

## Monorepo (Greenfield)

### Root Taskfile.yml

```yaml
version: '3'

dotenv: ['.env']

includes:
  backend:
    taskfile: ./backend/Taskfile.yml
    dir: ./backend
  frontend:
    taskfile: ./frontend/Taskfile.yml
    dir: ./frontend

vars:
  MONOREPO_NAME: my-monorepo

tasks:
  default:
    desc: List all tasks
    cmds:
      - task --list

  install:
    desc: Install all dependencies
    deps:
      - backend:install
      - frontend:install

  build:
    desc: Build all projects
    deps:
      - backend:build
      - frontend:build

  test:
    desc: Test all projects
    deps:
      - backend:test
      - frontend:test

  clean:
    desc: Clean all projects
    deps:
      - backend:clean
      - frontend:clean
```

### Backend Taskfile (backend/Taskfile.yml)

```yaml
version: '3'

dotenv:
  - ../.env          # Inherit from root
  - .env.local       # Local overrides

vars:
  PROJECT_NAME: backend

tasks:
  install:
    desc: Install backend dependencies
    cmds:
      - npm install

  build:
    desc: Build backend
    deps: [install]
    cmds:
      - npm run build

  test:
    desc: Run backend tests
    deps: [build]
    cmds:
      - npm test

  clean:
    desc: Clean backend artifacts
    cmds:
      - rm -rf dist/ node_modules/.cache/
```

### Frontend Taskfile (frontend/Taskfile.yml)

```yaml
version: '3'

dotenv:
  - ../.env
  - .env.local

vars:
  PROJECT_NAME: frontend

tasks:
  install:
    desc: Install frontend dependencies
    cmds:
      - npm install

  build:
    desc: Build frontend
    deps: [install]
    cmds:
      - npm run build

  test:
    desc: Run frontend tests
    deps: [build]
    cmds:
      - npm test

  dev:
    desc: Start dev server
    deps: [install]
    cmds:
      - npm run dev

  clean:
    desc: Clean frontend artifacts
    cmds:
      - rm -rf dist/ .next/ node_modules/.cache/
```

## Essential Features for New Projects

### 1. Always Include a Default Task

```yaml
tasks:
  default:
    desc: List all available tasks
    cmds:
      - task --list
```

This makes it easy to discover tasks: just run `task`

### 2. Set Up Environment Variables

```yaml
dotenv: ['.env', '.env.local']

# Create .env.example for documentation
tasks:
  init:
    desc: Initialize environment
    cmds:
      - cp .env.example .env
      - echo "Edit .env with your configuration"
```

### 3. Add Up-to-Date Checks

Avoid unnecessary rebuilds:

```yaml
tasks:
  build:
    desc: Build the project
    cmds:
      - npm run build
    sources:
      - 'src/**/*.ts'
      - package.json
    generates:
      - 'dist/**/*.js'
    method: checksum  # More accurate than timestamp
```

### 4. Configure Task Dependencies

```yaml
tasks:
  deploy:
    desc: Deploy to production
    deps:
      - test      # Run tests first
      - package   # Then package
    cmds:
      - # deployment commands
```

### 5. Add Preconditions

```yaml
tasks:
  deploy:
    desc: Deploy to production
    preconditions:
      - test -f .env.prod
      - sh: 'git status --porcelain | wc -l | grep -q "^0$"'
        msg: 'Working directory must be clean'
    requires:
      vars: [DEPLOY_KEY]
    cmds:
      - # deployment commands
```

## Project Initialization Checklist

- [ ] Copy appropriate template from `assets/templates/`
- [ ] Customize project name and version
- [ ] Add default task that runs `task --list`
- [ ] Set up .env file handling
- [ ] Configure install, build, test, clean tasks
- [ ] Add task dependencies with `deps:`
- [ ] Configure up-to-date checks with `sources:` and `generates:`
- [ ] Add `.task/` to `.gitignore`
- [ ] Document required environment variables
- [ ] Test all tasks work correctly

## Best Practices for Greenfield Projects

1. **Start with the template**: Don't reinvent the wheel
2. **Use standard task names**: build, test, deploy, etc.
3. **Add descriptions**: Every task should have a `desc:` field
4. **Configure dependencies**: Use `deps:` to show relationships
5. **Set up caching**: Use `sources:` and `generates:` from the start
6. **Handle environments**: Use `.env` files for configuration
7. **Add to .gitignore**: Include `.task/` in your .gitignore
8. **Document variables**: Use `requires:` for mandatory variables

## Next Steps

- **Advanced features**: See `references/advanced-features.md`
- **CI/CD integration**: See `references/taskfile-comprehensive-guide.md` section on CI/CD
- **Monorepo patterns**: See SKILL.md section on Advanced Monorepo Setup
