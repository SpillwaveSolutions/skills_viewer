# Analyzing Deployment Architecture from Taskfiles

## Overview

Taskfiles contain valuable information about deployment architecture, service dependencies, and infrastructure patterns. This guide shows how to extract and analyze deployment information from Taskfiles.

## Key Deployment Indicators in Taskfiles

### 1. Deployment Tasks and Dependencies

The `deploy` task and its dependencies reveal the deployment sequence:

```yaml
tasks:
  deploy:
    desc: Deploy all services
    deps:
      - infra:provision      # Infrastructure first
      - db:migrate           # Database migrations
      - backend:deploy       # Backend services
      - frontend:deploy      # Frontend last
    cmds:
      - echo "Deployment complete"
```

**Architecture insights**:
- Infrastructure provisioning happens first
- Database migrations before application deployment
- Backend deploys before frontend
- Multi-tier architecture (infrastructure → data → backend → frontend)

### 2. Service Organization

`includes:` reveal the service topology:

```yaml
includes:
  # Core services
  api-gateway:
    taskfile: ./services/api-gateway/Taskfile.yml
  auth-service:
    taskfile: ./services/auth/Taskfile.yml
  user-service:
    taskfile: ./services/user/Taskfile.yml

  # Data layer
  postgres:
    taskfile: ./databases/postgres/Taskfile.yml
  redis:
    taskfile: ./databases/redis/Taskfile.yml

  # Infrastructure
  terraform:
    taskfile: ./infra/terraform/Taskfile.yml
    internal: true
```

**Architecture pattern**: Microservices with:
- API Gateway (entry point)
- Auth service (authentication/authorization)
- User service (user management)
- PostgreSQL (primary database)
- Redis (caching/sessions)
- Terraform (infrastructure as code)

### 3. Environment Configuration

`dotenv:` and environment-specific tasks reveal deployment targets:

```yaml
dotenv:
  - .env
  - '.env.{{.ENV}}'    # .env.dev, .env.staging, .env.prod

tasks:
  deploy:dev:
    desc: Deploy to development
    cmds:
      - task deploy ENV=dev

  deploy:staging:
    desc: Deploy to staging
    cmds:
      - task deploy ENV=staging

  deploy:prod:
    desc: Deploy to production
    preconditions:
      - sh: 'git rev-parse --abbrev-ref HEAD | grep -q "^main$"'
        msg: 'Must deploy from main branch'
    cmds:
      - task deploy ENV=prod
```

**Deployment strategy**:
- Multiple environments: dev, staging, prod
- Production has safeguards (must be on main branch)
- Environment-specific configuration

### 4. Cloud Provider Detection

Commands reveal the cloud platform:

```yaml
# AWS
tasks:
  deploy:
    cmds:
      - aws ecr get-login-password | docker login
      - aws ecs update-service

# GCP
tasks:
  deploy:
    cmds:
      - gcloud auth configure-docker
      - gcloud run deploy

# Azure
tasks:
  deploy:
    cmds:
      - az acr login
      - az containerapp update

# Kubernetes
tasks:
  deploy:
    cmds:
      - kubectl apply -f k8s/
      - helm upgrade myapp
```

### 5. Container and Registry Information

```yaml
vars:
  DOCKER_REGISTRY: us-central1-docker.pkg.dev/my-project
  IMAGE_NAME: my-app
  IMAGE_TAG:
    sh: git rev-parse --short HEAD

tasks:
  docker:build:
    desc: Build Docker image
    cmds:
      - docker build -t {{.DOCKER_REGISTRY}}/{{.IMAGE_NAME}}:{{.IMAGE_TAG}} .

  docker:push:
    desc: Push to registry
    deps: [docker:build]
    cmds:
      - docker push {{.DOCKER_REGISTRY}}/{{.IMAGE_NAME}}:{{.IMAGE_TAG}}
```

**Infrastructure insights**:
- Uses GCP Artifact Registry (us-central1)
- Container-based deployment
- Git SHA as image tag (immutable deployments)

## Extracting Architecture Patterns

### Pattern 1: Three-Tier Architecture

```yaml
# Root Taskfile.yml
includes:
  # Presentation tier
  web: ./web/Taskfile.yml
  mobile: ./mobile/Taskfile.yml

  # Application tier
  api: ./api/Taskfile.yml
  business-logic: ./services/Taskfile.yml

  # Data tier
  database: ./database/Taskfile.yml
  cache: ./cache/Taskfile.yml

tasks:
  deploy:
    deps:
      - database:migrate      # Data tier first
      - cache:deploy
      - api:deploy            # Application tier
      - business-logic:deploy
      - web:deploy            # Presentation tier last
      - mobile:deploy
```

**Diagram structure**:
```
┌─────────────────────────────────────┐
│     Presentation Tier               │
│  ┌──────┐           ┌──────────┐   │
│  │ Web  │           │  Mobile  │   │
│  └──────┘           └──────────┘   │
└─────────────┬───────────────────────┘
              │
┌─────────────▼───────────────────────┐
│     Application Tier                │
│  ┌──────┐    ┌────────────────┐    │
│  │ API  │    │ Business Logic │    │
│  └──────┘    └────────────────┘    │
└─────────────┬───────────────────────┘
              │
┌─────────────▼───────────────────────┐
│     Data Tier                       │
│  ┌──────────┐      ┌───────┐       │
│  │ Database │      │ Cache │       │
│  └──────────┘      └───────┘       │
└─────────────────────────────────────┘
```

### Pattern 2: Microservices Architecture

```yaml
includes:
  # Gateway layer
  api-gateway: ./services/gateway/Taskfile.yml

  # Service layer
  auth-service: ./services/auth/Taskfile.yml
  user-service: ./services/user/Taskfile.yml
  order-service: ./services/order/Taskfile.yml
  payment-service: ./services/payment/Taskfile.yml
  notification-service: ./services/notification/Taskfile.yml

  # Shared infrastructure
  message-bus: ./infra/kafka/Taskfile.yml
  service-mesh: ./infra/istio/Taskfile.yml

tasks:
  deploy:
    deps:
      - message-bus:deploy
      - service-mesh:deploy
      - auth-service:deploy
      - user-service:deploy
      - order-service:deploy
      - payment-service:deploy
      - notification-service:deploy
      - api-gateway:deploy
```

**Architecture insights**:
- API Gateway as entry point
- Independent microservices
- Message bus (Kafka) for async communication
- Service mesh (Istio) for service-to-service communication

### Pattern 3: Serverless Architecture

```yaml
tasks:
  deploy:
    desc: Deploy serverless functions
    cmds:
      - task: deploy:api-gateway
      - task: deploy:lambda-functions
      - task: deploy:dynamodb-tables
      - task: deploy:s3-buckets

  deploy:lambda-functions:
    cmds:
      - aws lambda update-function-code --function-name user-handler
      - aws lambda update-function-code --function-name order-handler
      - aws lambda update-function-code --function-name payment-handler

  deploy:api-gateway:
    cmds:
      - aws apigatewayv2 update-api
```

**Architecture insights**:
- AWS Lambda functions
- API Gateway for HTTP routing
- DynamoDB (NoSQL database)
- S3 for storage
- Event-driven, serverless pattern

## Analyzing Service Dependencies

### Dependency Graph from Task Deps

```yaml
tasks:
  deploy:api:
    deps:
      - deploy:database
      - deploy:redis
      - deploy:message-queue
    cmds:
      - # deploy API

  deploy:worker:
    deps:
      - deploy:database
      - deploy:message-queue
    cmds:
      - # deploy worker

  deploy:frontend:
    deps:
      - deploy:api
    cmds:
      - # deploy frontend
```

**Dependency graph**:
```
Database ────────┬─────── API ──────── Frontend
                 │
Redis ───────────┤
                 │
Message Queue ───┴─────── Worker
```

## Infrastructure as Code Detection

### Terraform

```yaml
includes:
  terraform:
    taskfile: ./infra/terraform/Taskfile.yml

tasks:
  infra:plan:
    desc: Preview infrastructure changes
    cmds:
      - terraform plan

  infra:apply:
    desc: Apply infrastructure changes
    cmds:
      - terraform apply

  deploy:
    deps:
      - infra:apply
      - # other deployment tasks
```

### Pulumi

```yaml
tasks:
  infra:up:
    desc: Deploy infrastructure with Pulumi
    cmds:
      - pulumi up --stack {{.ENV}}

  deploy:
    deps:
      - infra:up
```

### Kubernetes

```yaml
tasks:
  k8s:apply:
    desc: Apply Kubernetes manifests
    cmds:
      - kubectl apply -f k8s/namespace.yaml
      - kubectl apply -f k8s/configmap.yaml
      - kubectl apply -f k8s/secrets.yaml
      - kubectl apply -f k8s/deployment.yaml
      - kubectl apply -f k8s/service.yaml
      - kubectl apply -f k8s/ingress.yaml
```

## Extracting Network and Port Information

```yaml
vars:
  # Service ports
  API_PORT: 8080
  WEB_PORT: 3000
  AUTH_PORT: 8081

  # Database ports
  POSTGRES_PORT: 5432
  REDIS_PORT: 6379

  # External endpoints
  API_URL: https://api.example.com
  WEB_URL: https://www.example.com

tasks:
  run:local:
    desc: Run all services locally
    cmds:
      - docker-compose up -d postgres redis
      - task auth-service:run PORT={{.AUTH_PORT}}
      - task api:run PORT={{.API_PORT}}
      - task web:run PORT={{.WEB_PORT}}
```

**Network diagram structure**:
```
Internet
    │
    ├─── Web (3000) ──┐
    │                 │
    └─── API (8080) ──┴─── Auth Service (8081)
           │
           ├─── PostgreSQL (5432)
           └─── Redis (6379)
```

## Deployment Flow Analysis

### Sequential Deployment

```yaml
tasks:
  deploy:
    desc: Deploy with sequential steps
    cmds:
      - task: backup:database
      - task: infra:provision
      - task: database:migrate
      - task: backend:deploy
      - task: frontend:deploy
      - task: smoke:test
```

**Flow**: backup → provision → migrate → backend → frontend → test

### Parallel Deployment

```yaml
tasks:
  deploy:microservices:
    desc: Deploy microservices in parallel
    deps:
      - auth-service:deploy
      - user-service:deploy
      - order-service:deploy
      - payment-service:deploy
```

**Flow**: All services deploy simultaneously (after their individual dependencies)

### Blue-Green Deployment

```yaml
tasks:
  deploy:blue-green:
    desc: Blue-green deployment strategy
    cmds:
      - task: deploy:green-environment
      - task: test:green-environment
      - task: switch:traffic-to-green
      - task: monitor:green-environment
      - task: decommission:blue-environment
```

### Canary Deployment

```yaml
tasks:
  deploy:canary:
    desc: Canary deployment strategy
    cmds:
      - task: deploy:canary VERSION={{.NEW_VERSION}} TRAFFIC=10
      - task: monitor:canary DURATION=30m
      - task: deploy:canary TRAFFIC=50
      - task: monitor:canary DURATION=30m
      - task: deploy:canary TRAFFIC=100
```

## Generating Architecture Documentation

Use the information extracted from Taskfiles to:

1. **Create deployment diagrams** (see `references/diagram-generation.md`)
2. **Document service dependencies**
3. **Map network topology**
4. **Identify infrastructure components**
5. **Visualize deployment flow**

### Example Analysis Script Usage

```bash
# Analyze project structure
task analyze:architecture

# Generate deployment diagram
task generate:deployment-diagram

# Export service map
task export:service-map
```

## Next Steps

- **Generate diagrams**: See `references/diagram-generation.md`
- **Advanced analysis**: See `scripts/analyze_taskfile.py`
- **Integration with Mermaid**: Invoke design-doc-mermaid skill
- **Integration with PlantUML**: Invoke plantuml skill
