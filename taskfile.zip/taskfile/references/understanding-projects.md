# Understanding Projects Through Taskfiles

## Overview

Taskfiles serve as living, executable documentation for projects. This guide shows how to read and understand projects by analyzing their Taskfiles.

## The Critical First Step

**ALWAYS run `task --list` first** when encountering a new project with a Taskfile. This immediately reveals:
- All available operations
- Task descriptions
- Project capabilities
- Workflow structure

```bash
# First command to run
task --list

# Or just run the default task
task
```

## What Taskfiles Tell You About Projects

### 1. Project Type and Tech Stack

The commands in tasks reveal the technology:

```yaml
# Maven Java project
tasks:
  build:
    cmds:
      - mvn compile      # Maven detected

# Python project
tasks:
  test:
    cmds:
      - pytest           # Python with pytest

# Node.js project
tasks:
  build:
    cmds:
      - npm run build    # NPM/Node.js

# Docker project
tasks:
  deploy:
    cmds:
      - docker build     # Docker-based
```

### 2. Project Structure

`includes:` reveal modular organization:

```yaml
includes:
  backend: ./backend/Taskfile.yml       # Backend in backend/
  frontend: ./frontend/Taskfile.yml     # Frontend in frontend/
  api: ./api/Taskfile.yml               # API service in api/
  utils:
    taskfile: ./scripts/utils/Taskfile.yml
    internal: true                       # Hidden utility scripts
```

**This tells us**:
- Monorepo with 3 main projects: backend, frontend, api
- Utility scripts are organized in scripts/utils/
- Each component has its own Taskfile

### 3. Development Workflow

Task dependencies show the workflow order:

```yaml
tasks:
  deploy:
    desc: Deploy to environment
    deps: [package]      # Runs package first
    cmds:
      - # deploy commands

  package:
    desc: Create distribution
    deps: [test]         # Runs test first
    cmds:
      - # package commands

  test:
    desc: Run tests
    deps: [build]        # Runs build first
    cmds:
      - # test commands

  build:
    desc: Build project
    deps: [clean]        # Runs clean first
    cmds:
      - # build commands
```

**Workflow discovered**: clean → build → test → package → deploy

### 4. Environment Requirements

`dotenv:`, `requires:`, and `preconditions:` show what's needed:

```yaml
# Environment file loading
dotenv:
  - .env                # Global config
  - .env.local          # Local overrides
  - '.env.{{.ENV}}'     # Environment-specific (.env.dev, .env.prod)

tasks:
  deploy:
    requires:
      vars: [AWS_REGION, DEPLOY_KEY]    # These vars must be set
    preconditions:
      - test -f .env.prod                # Must have .env.prod file
      - sh: 'which aws'                  # AWS CLI must be installed
        msg: 'AWS CLI not found'
```

**This tells us**:
- Project uses .env files for configuration
- Supports multiple environments (dev, prod, etc.)
- Deployment needs AWS_REGION and DEPLOY_KEY
- AWS CLI is required for deployment

### 5. Available Operations

Standard task names reveal capabilities:

```yaml
tasks:
  build:        # Can build the project
  test:         # Has tests
  coverage:     # Generates coverage reports
  lint:         # Code linting available
  format:       # Code formatting available
  deploy:       # Can be deployed
  package:      # Creates distribution artifacts
  migrate:      # Has database migrations
  seed:         # Can seed database
  backup:       # Database backup capability
  docker:build: # Docker support
  docker:push:  # Can push to registry
```

### 6. Quality Standards

Quality tasks show the project's standards:

```yaml
tasks:
  lint:
    desc: Check code quality
    cmds:
      - eslint .
      - ruff check .

  coverage:
    desc: Ensure 80% test coverage
    cmds:
      - pytest --cov=. --cov-report=html --cov-fail-under=80

  audit:
    desc: Security vulnerability scan
    cmds:
      - npm audit
      - safety check
```

**This tells us**:
- Project enforces linting standards
- Requires 80% test coverage
- Runs security audits

## Reading a Monorepo Taskfile

### Example: E-commerce Platform

```yaml
# Root Taskfile.yml
version: '3'

dotenv: ['.env']

includes:
  api:
    taskfile: ./services/api/Taskfile.yml
    dir: ./services/api
  web:
    taskfile: ./apps/web/Taskfile.yml
    dir: ./apps/web
  mobile:
    taskfile: ./apps/mobile/Taskfile.yml
    dir: ./apps/mobile
  db:
    taskfile: ./services/database/Taskfile.yml
    dir: ./services/database
  infra:
    taskfile: ./infrastructure/Taskfile.yml
    dir: ./infrastructure
    internal: true

vars:
  PLATFORM_NAME: ecommerce-platform
  VERSION: '2.1.0'

tasks:
  default:
    cmds:
      - task --list

  install:
    desc: Install all dependencies
    deps:
      - api:install
      - web:install
      - mobile:install

  build:
    desc: Build all services and apps
    deps:
      - api:build
      - web:build
      - mobile:build

  test:
    desc: Run all tests
    deps:
      - api:test
      - web:test
      - mobile:test

  deploy:
    desc: Deploy all services
    deps:
      - infra:setup
      - db:migrate
      - api:deploy
      - web:deploy

  ci:
    desc: Run full CI pipeline
    cmds:
      - task clean
      - task install
      - task lint
      - task test
      - task coverage:all
      - task build
```

### What We Learn

**Architecture**:
- Monorepo with services and apps
- Service: API (backend)
- Apps: Web (frontend), Mobile
- Database: Separate service
- Infrastructure: Managed via Task

**Deployment Order**:
1. Infrastructure setup (`infra:setup`)
2. Database migrations (`db:migrate`)
3. API deployment (`api:deploy`)
4. Web deployment (`web:deploy`)

**Workflow**:
- Standard CI pipeline: clean → install → lint → test → coverage → build
- Parallel execution possible for independent tasks

**Project Scale**:
- Enterprise-level (multiple services and apps)
- Version 2.1.0 (mature project)
- Well-organized with infrastructure as code

## Extracting Project Documentation

### Command Patterns

```yaml
# Java Spring Boot with PostgreSQL
tasks:
  run:
    cmds:
      - java -jar target/app.jar --spring.profiles.active=dev

# Python FastAPI with Redis
tasks:
  dev:
    cmds:
      - uvicorn main:app --reload --port 8000
      - redis-server &

# Node.js with MongoDB
tasks:
  start:
    cmds:
      - mongod --fork
      - npm start
```

**Reveals**:
- Java project uses Spring Boot
- Python project uses FastAPI and Redis
- Node.js project uses MongoDB

### Port and Service Information

```yaml
vars:
  API_PORT: 8080
  WEB_PORT: 3000
  DB_PORT: 5432

tasks:
  run:
    cmds:
      - echo "API running on http://localhost:{{.API_PORT}}"
      - echo "Web running on http://localhost:{{.WEB_PORT}}"
```

**Reveals**:
- API runs on port 8080
- Web runs on port 3000
- PostgreSQL on port 5432

### Integration Points

```yaml
tasks:
  deploy:
    deps:
      - task: auth-service:deploy
      - task: payment-service:deploy
      - task: notification-service:deploy
```

**Reveals**:
- Microservices architecture
- Services: auth, payment, notification
- Deployment dependencies

## Practical Analysis Workflow

### Step 1: Initial Discovery

```bash
# List all tasks
task --list

# See the raw Taskfile
cat Taskfile.yml
```

### Step 2: Identify Entry Points

Look for these tasks:
- `default` - What happens when you run `task`
- `install` - How to set up
- `run` or `dev` - How to start the application
- `test` - How to run tests

### Step 3: Trace Dependencies

```bash
# Run with dry-run to see execution order
task --dry deploy

# Output shows:
# task: [clean]
# task: [install]
# task: [build]
# task: [test]
# task: [package]
# task: [deploy]
```

### Step 4: Check Environment Needs

```bash
# Look for .env files mentioned
grep "dotenv:" Taskfile.yml

# Check for required variables
grep "requires:" Taskfile.yml

# Look for preconditions
grep "preconditions:" Taskfile.yml
```

### Step 5: Understand Subprojects

```bash
# List included taskfiles
grep -A 2 "includes:" Taskfile.yml

# Run subproject tasks
task backend:test
task frontend:build
```

## Using Taskfiles as Onboarding Documentation

When joining a new project:

1. **Run `task --list`** - See all capabilities
2. **Read the Taskfile** - Understand structure
3. **Run `task install`** - Set up dependencies
4. **Run `task test`** - Verify setup
5. **Run `task dev` or `task run`** - Start working

The Taskfile provides:
- ✅ Complete list of operations
- ✅ Execution order via dependencies
- ✅ Required environment variables
- ✅ Tech stack information
- ✅ Project structure (via includes)
- ✅ Quality standards (via lint, coverage tasks)

## Next Steps

- **Deployment architecture**: See `references/deployment-analysis.md`
- **Generate diagrams**: See `references/diagram-generation.md`
- **Advanced features**: See `references/advanced-features.md`
