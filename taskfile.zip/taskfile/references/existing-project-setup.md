# Setting Up Task for Existing Projects

## Overview

This guide covers adding Task to existing projects that already have build systems, scripts, or Makefiles.

## Pre-Setup Analysis

Before creating a Taskfile, analyze the existing project:

### 1. Identify Existing Build System
```bash
# Check for existing build files
ls -la | grep -E "(Makefile|package.json|pom.xml|build.gradle|pyproject.toml|Cargo.toml)"

# Check for script directories
find . -name "scripts" -type d
```

### 2. Document Current Workflows

Identify common operations:
- **Build**: How is the project built? (mvn compile, npm run build, cargo build, etc.)
- **Test**: How are tests run? (mvn test, npm test, pytest, etc.)
- **Deploy**: How is deployment done? (scripts, manual, CI/CD)
- **Clean**: How are artifacts cleaned? (mvn clean, rm -rf build/, etc.)

### 3. Check for Environment Files
```bash
# Look for environment configuration
ls -la .env* 2>/dev/null
```

## Step-by-Step Setup

### Step 1: Choose the Right Template

Based on your tech stack, select a template from `assets/templates/`:

| Tech Stack | Template | Detection Command |
|------------|----------|-------------------|
| Maven | Taskfile-maven.yml | `ls pom.xml` |
| Gradle | Taskfile-gradle.yml | `ls build.gradle*` |
| Poetry (Python) | Taskfile-poetry.yml | `ls pyproject.toml && grep poetry` |
| UV (Python) | Taskfile-uv.yml | `ls pyproject.toml && grep uv` |
| NPM (Node) | Taskfile-npm.yml | `ls package.json && grep npm` |
| Yarn (Node) | Taskfile-yarn.yml | `ls yarn.lock` |
| Docker | Taskfile-docker.yml | `ls Dockerfile` |
| Docker Compose | Taskfile-docker-compose.yml | `ls docker-compose.yml` |
| Monorepo | Taskfile-monorepo-root.yml | Multiple subprojects |

### Step 2: Copy and Customize Template

```bash
# Example: Maven project
cp assets/templates/Taskfile-maven.yml ./Taskfile.yml

# Open and customize
$EDITOR Taskfile.yml
```

### Step 3: Map Existing Commands to Standard Tasks

Update the Taskfile to match your project structure:

#### Example: Maven Project

**Before (manual commands)**:
```bash
mvn clean compile
mvn test
mvn package
mvn deploy
```

**After (Taskfile.yml)**:
```yaml
version: '3'

vars:
  PROJECT_NAME: my-app
  VERSION:
    sh: mvn help:evaluate -Dexpression=project.version -q -DforceStdout

tasks:
  clean:
    desc: Remove build artifacts
    cmds:
      - mvn clean

  build:
    desc: Compile the project
    deps: [clean]
    cmds:
      - mvn compile

  test:
    desc: Run unit tests
    deps: [build]
    cmds:
      - mvn test

  package:
    desc: Create JAR artifact
    deps: [test]
    cmds:
      - mvn package

  deploy:
    desc: Deploy to environment
    deps: [package]
    dotenv: ['.env.deploy']
    requires:
      vars: [ENV]
    cmds:
      - mvn deploy
```

### Step 4: Handle Environment Variables

If your project uses environment files:

```yaml
# Load .env files (later files override earlier)
dotenv: ['.env', '.env.local']

# Or environment-specific
dotenv:
  - .env
  - '.env.{{.ENV}}'  # .env.dev, .env.prod, etc.
```

### Step 5: Integrate Existing Scripts

If you have utility scripts:

```yaml
tasks:
  migrate:
    desc: Run database migrations
    cmds:
      - bash scripts/migrate.sh

  seed:
    desc: Seed database with test data
    cmds:
      - python scripts/seed_db.py

  backup:
    desc: Backup production database
    preconditions:
      - test -f .env.prod
    cmds:
      - bash scripts/backup.sh
```

For better organization, create a utils namespace:
```yaml
includes:
  utils:
    taskfile: ./scripts/Taskfile.yml
    internal: true
```

### Step 6: Test the Taskfile

```bash
# List all tasks
task --list

# Test each task
task build
task test
task package

# Verify dependencies work
task deploy  # Should run package → test → build → clean
```

## Common Migration Patterns

### From Makefile to Taskfile

**Makefile**:
```makefile
.PHONY: all build test clean

all: build

build: clean
	mvn compile

test: build
	mvn test

clean:
	mvn clean
```

**Taskfile.yml**:
```yaml
version: '3'

tasks:
  default:
    desc: List all tasks
    cmds:
      - task --list

  clean:
    desc: Remove build artifacts
    cmds:
      - mvn clean

  build:
    desc: Compile the project
    deps: [clean]
    cmds:
      - mvn compile

  test:
    desc: Run unit tests
    deps: [build]
    cmds:
      - mvn test
```

### From package.json Scripts to Taskfile

**package.json**:
```json
{
  "scripts": {
    "build": "tsc",
    "test": "jest",
    "lint": "eslint .",
    "dev": "nodemon"
  }
}
```

**Taskfile.yml**:
```yaml
version: '3'

tasks:
  install:
    desc: Install dependencies
    cmds:
      - npm install

  build:
    desc: Build TypeScript
    deps: [install]
    cmds:
      - npm run build

  test:
    desc: Run tests with Jest
    deps: [build]
    cmds:
      - npm test

  lint:
    desc: Lint code
    cmds:
      - npm run lint

  dev:
    desc: Start development server
    cmds:
      - npm run dev
```

## Monorepo Projects

For monorepos, create a hierarchical structure:

### Root Taskfile.yml
```yaml
version: '3'

includes:
  backend: ./backend/Taskfile.yml
  frontend: ./frontend/Taskfile.yml

tasks:
  install:
    desc: Install all dependencies
    deps:
      - backend:install
      - frontend:install

  build:
    desc: Build all projects
    deps:
      - backend:build
      - frontend:build

  test:
    desc: Test all projects
    deps:
      - backend:test
      - frontend:test
```

### Subproject Taskfiles
Each subproject (backend/, frontend/) gets its own Taskfile with tech-stack-specific tasks.

## Best Practices for Existing Projects

1. **Start small**: Begin with core tasks (build, test, clean)
2. **Keep existing tools**: Task wraps existing commands, doesn't replace them
3. **Standardize naming**: Use consistent task names across projects
4. **Document dependencies**: Use `deps:` to show task relationships
5. **Preserve scripts**: Keep utility scripts, wrap them with Task
6. **Use .gitignore**: Add `.task/` to .gitignore (Task's cache directory)

## Gradual Migration

You don't need to migrate everything at once:

### Phase 1: Core Tasks
- build
- test
- clean

### Phase 2: Quality Tasks
- lint
- format
- audit

### Phase 3: Deployment Tasks
- package
- deploy
- release

### Phase 4: Utility Tasks
- migrate
- seed
- backup

## Troubleshooting

### Tasks fail with "command not found"
- Ensure build tools are installed
- Check if paths are correct
- Set working directory with `dir:` if needed

### Environment variables not loading
- Verify .env file paths
- Check file order in `dotenv:` array
- Use `task --verbose` for debugging

### Existing scripts break
- Check working directory: use `dir:` in task
- Verify environment variable names
- Ensure script permissions: `chmod +x script.sh`

## Next Steps

- **Advanced features**: See `references/advanced-features.md`
- **Troubleshooting**: See `references/troubleshooting.md`
- **Understanding projects**: See `references/understanding-projects.md`
