# Task Installation Guide

## Overview

Task is a modern task runner written in Go that uses YAML-based Taskfile.yml files. This guide covers installation methods across different platforms.

## Quick Install (Recommended)

### macOS
```bash
# Using Homebrew (recommended)
brew install go-task/tap/go-task

# Verify installation
task --version
```

### Linux
```bash
# Using snap
sudo snap install task --classic

# Or using shell script (installs to ./bin by default)
sh -c "$(curl -fsSL https://taskfile.dev/install.sh)"

# Verify installation
task --version
```

### Windows
```powershell
# Using Scoop
scoop install task

# Or using Chocolatey
choco install go-task

# Verify installation
task --version
```

## Alternative Installation Methods

### Go Install
```bash
# If you have Go installed
go install github.com/go-task/task/v3/cmd/task@latest

# Add to PATH if needed
export PATH=$PATH:$(go env GOPATH)/bin
```

### NPM Package
```bash
# Install as dev dependency in Node projects
npm install --save-dev @go-task/cli

# Use via npx
npx task --version
```

### Download Binary
1. Visit https://github.com/go-task/task/releases
2. Download the appropriate binary for your OS/architecture
3. Extract and move to a directory in your PATH
4. Make executable (Linux/macOS): `chmod +x task`

## Verification

After installation, verify Task is working:

```bash
# Check version
task --version

# Should output something like: Task version: v3.x.x
```

## Updating Task

### Homebrew (macOS)
```bash
brew upgrade go-task
```

### Snap (Linux)
```bash
sudo snap refresh task
```

### Scoop (Windows)
```powershell
scoop update task
```

### Go Install
```bash
go install github.com/go-task/task/v3/cmd/task@latest
```

## Post-Installation

Once Task is installed:

1. **Create your first Taskfile**: `touch Taskfile.yml`
2. **Use templates**: Reference the taskfile skill's assets/templates/ for ready-to-use templates
3. **Read existing Taskfiles**: Run `task --list` in any project with a Taskfile

## Shell Completion (Optional)

Task supports shell completion for bash, zsh, and fish:

### Bash
```bash
task --completion bash > /etc/bash_completion.d/task
```

### Zsh
```bash
task --completion zsh > "${fpath[1]}/_task"
```

### Fish
```bash
task --completion fish > ~/.config/fish/completions/task.fish
```

## Troubleshooting Installation

### Command not found
- Ensure the binary is in your PATH
- For Go install, check: `echo $PATH | grep $(go env GOPATH)/bin`
- Restart your terminal after installation

### Permission denied
- On Linux/macOS, ensure the binary is executable: `chmod +x /path/to/task`
- For system directories, use sudo if needed

### Version mismatch
- Some package managers may have older versions
- Use Go install or download binary directly for the latest version
- Check https://github.com/go-task/task/releases for current version

## Next Steps

After installation:
- **New projects**: See `references/greenfield-setup.md`
- **Existing projects**: See `references/existing-project-setup.md`
- **Understanding projects**: See `references/understanding-projects.md`
