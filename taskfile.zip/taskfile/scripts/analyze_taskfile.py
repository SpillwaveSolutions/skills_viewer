#!/usr/bin/env python3
"""
Analyze Taskfile.yml and extract architecture information.

This script analyzes Taskfiles to extract:
- Service dependencies
- Deployment flows
- Architecture patterns
- Infrastructure components
- Environment configurations

Can generate Mermaid and PlantUML diagrams from the analysis.

Usage:
    python analyze_taskfile.py [taskfile_path] [--format mermaid|plantuml|json]
    python analyze_taskfile.py --help
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List, Any, Optional

try:
    import yaml
except ImportError:
    print("Error: PyYAML not installed. Install with: pip install pyyaml", file=sys.stderr)
    sys.exit(1)


class TaskfileAnalyzer:
    """Analyzes Taskfile.yml structure and extracts architecture information."""

    def __init__(self, taskfile_path: str):
        self.taskfile_path = Path(taskfile_path)
        self.data = self._load_taskfile()
        self.analysis = self._analyze()

    def _load_taskfile(self) -> Dict[str, Any]:
        """Load and parse Taskfile.yml."""
        if not self.taskfile_path.exists():
            raise FileNotFoundError(f"Taskfile not found: {self.taskfile_path}")

        with open(self.taskfile_path) as f:
            return yaml.safe_load(f) or {}

    def _analyze(self) -> Dict[str, Any]:
        """Perform comprehensive analysis of Taskfile."""
        return {
            'metadata': self._extract_metadata(),
            'services': self._extract_services(),
            'tasks': self._extract_tasks(),
            'dependencies': self._extract_dependencies(),
            'deployment_flow': self._extract_deployment_flow(),
            'environment': self._extract_environment(),
            'architecture_pattern': self._detect_architecture_pattern(),
            'cloud_provider': self._detect_cloud_provider(),
            'tech_stack': self._detect_tech_stack(),
        }

    def _extract_metadata(self) -> Dict[str, Any]:
        """Extract metadata from Taskfile."""
        vars_section = self.data.get('vars', {})
        return {
            'version': self.data.get('version', 'unknown'),
            'project_name': vars_section.get('PROJECT_NAME', 'unknown'),
            'project_version': vars_section.get('VERSION', 'unknown'),
            'variables': vars_section,
        }

    def _extract_services(self) -> List[Dict[str, Any]]:
        """Extract service information from includes."""
        includes = self.data.get('includes', {})
        services = []

        for name, config in includes.items():
            if isinstance(config, str):
                # Simple include: name: path
                services.append({
                    'name': name,
                    'path': config,
                    'internal': False,
                    'optional': False,
                })
            elif isinstance(config, dict):
                # Complex include with options
                services.append({
                    'name': name,
                    'path': config.get('taskfile', ''),
                    'dir': config.get('dir', ''),
                    'internal': config.get('internal', False),
                    'optional': config.get('optional', False),
                    'aliases': config.get('aliases', []),
                })

        return services

    def _extract_tasks(self) -> List[Dict[str, Any]]:
        """Extract task information."""
        tasks_section = self.data.get('tasks', {})
        tasks = []

        for name, config in tasks_section.items():
            if isinstance(config, dict):
                tasks.append({
                    'name': name,
                    'description': config.get('desc', ''),
                    'dependencies': config.get('deps', []),
                    'commands': config.get('cmds', []),
                    'required_vars': config.get('requires', {}).get('vars', []),
                    'preconditions': config.get('preconditions', []),
                })

        return tasks

    def _extract_dependencies(self) -> Dict[str, List[str]]:
        """Extract task dependency graph."""
        tasks_section = self.data.get('tasks', {})
        dependencies = {}

        for name, config in tasks_section.items():
            if isinstance(config, dict):
                deps = config.get('deps', [])
                # Handle both string and dict deps
                dep_names = []
                for dep in deps:
                    if isinstance(dep, str):
                        dep_names.append(dep)
                    elif isinstance(dep, dict) and 'task' in dep:
                        dep_names.append(dep['task'])
                dependencies[name] = dep_names

        return dependencies

    def _extract_deployment_flow(self) -> List[str]:
        """Extract deployment flow from deploy task."""
        tasks_section = self.data.get('tasks', {})
        deploy_task = tasks_section.get('deploy', {})

        if not deploy_task:
            return []

        # Check deps first
        deps = deploy_task.get('deps', [])
        if deps:
            flow = []
            for dep in deps:
                if isinstance(dep, str):
                    flow.append(dep)
                elif isinstance(dep, dict) and 'task' in dep:
                    flow.append(dep['task'])
            return flow

        # Check cmds
        cmds = deploy_task.get('cmds', [])
        if cmds:
            flow = []
            for cmd in cmds:
                if isinstance(cmd, dict) and 'task' in cmd:
                    flow.append(cmd['task'])
                elif isinstance(cmd, str) and cmd.startswith('task '):
                    # Extract task name from "task taskname"
                    flow.append(cmd.split()[1].strip())
            return flow

        return []

    def _extract_environment(self) -> Dict[str, Any]:
        """Extract environment configuration."""
        dotenv = self.data.get('dotenv', [])
        if isinstance(dotenv, str):
            dotenv = [dotenv]

        tasks_section = self.data.get('tasks', {})
        env_specific_tasks = []

        for name, config in tasks_section.items():
            if isinstance(config, dict):
                if 'dotenv' in config or '{{.ENV}}' in str(config):
                    env_specific_tasks.append(name)

        return {
            'dotenv_files': dotenv,
            'environment_specific_tasks': env_specific_tasks,
            'supports_multiple_environments': '{{.ENV}}' in str(self.data),
        }

    def _detect_architecture_pattern(self) -> str:
        """Detect architecture pattern from services and structure."""
        services = self._extract_services()
        service_names = [s['name'].lower() for s in services]

        # Detect microservices
        if any('service' in name for name in service_names):
            if 'gateway' in service_names or 'api-gateway' in service_names:
                return 'microservices-with-gateway'
            return 'microservices'

        # Detect three-tier
        has_presentation = any(name in service_names for name in ['web', 'frontend', 'mobile'])
        has_application = any(name in service_names for name in ['api', 'backend', 'business-logic'])
        has_data = any(name in service_names for name in ['database', 'db', 'cache', 'redis'])

        if has_presentation and has_application and has_data:
            return 'three-tier'

        # Detect monorepo
        if len(services) > 3:
            return 'monorepo'

        # Detect serverless
        tasks_str = str(self.data.get('tasks', {})).lower()
        if 'lambda' in tasks_str or 'serverless' in tasks_str:
            return 'serverless'

        return 'unknown'

    def _detect_cloud_provider(self) -> Optional[str]:
        """Detect cloud provider from commands."""
        tasks_str = str(self.data.get('tasks', {})).lower()

        if 'gcloud' in tasks_str or 'gcp' in tasks_str:
            return 'GCP'
        if 'aws' in tasks_str or 'eks' in tasks_str:
            return 'AWS'
        if 'az ' in tasks_str or 'azure' in tasks_str:
            return 'Azure'
        if 'kubectl' in tasks_str or 'helm' in tasks_str:
            return 'Kubernetes'

        return None

    def _detect_tech_stack(self) -> List[str]:
        """Detect technology stack from commands."""
        tasks_str = str(self.data.get('tasks', {})).lower()
        tech_stack = []

        # Languages/Frameworks
        if 'mvn' in tasks_str or 'maven' in tasks_str:
            tech_stack.append('Maven')
        if 'gradle' in tasks_str:
            tech_stack.append('Gradle')
        if 'npm' in tasks_str:
            tech_stack.append('NPM')
        if 'yarn' in tasks_str:
            tech_stack.append('Yarn')
        if 'poetry' in tasks_str or 'pytest' in tasks_str:
            tech_stack.append('Python')
        if 'cargo' in tasks_str:
            tech_stack.append('Rust')
        if 'go build' in tasks_str or 'go test' in tasks_str:
            tech_stack.append('Go')

        # Containers
        if 'docker' in tasks_str:
            tech_stack.append('Docker')
        if 'docker-compose' in tasks_str:
            tech_stack.append('Docker Compose')

        # Databases
        if 'postgres' in tasks_str or 'psql' in tasks_str:
            tech_stack.append('PostgreSQL')
        if 'mysql' in tasks_str:
            tech_stack.append('MySQL')
        if 'mongo' in tasks_str:
            tech_stack.append('MongoDB')
        if 'redis' in tasks_str:
            tech_stack.append('Redis')

        return tech_stack

    def generate_mermaid_service_graph(self) -> str:
        """Generate Mermaid service dependency diagram."""
        services = self.analysis['services']
        dependencies = self.analysis['dependencies']

        lines = ['graph TB']

        # Add service nodes
        for service in services:
            if not service['internal']:
                node_id = service['name'].replace('-', '_').replace(':', '_')
                lines.append(f"    {node_id}[{service['name']}]")

        # Add dependencies
        for task, deps in dependencies.items():
            task_id = task.replace('-', '_').replace(':', '_')
            for dep in deps:
                dep_id = dep.replace('-', '_').replace(':', '_')
                if ':' in dep:  # Service task reference
                    lines.append(f"    {dep_id} --> {task_id}")

        return '\n'.join(lines)

    def generate_mermaid_deployment_flow(self) -> str:
        """Generate Mermaid deployment flow diagram."""
        flow = self.analysis['deployment_flow']

        if not flow:
            return "graph TD\n    A[No deployment flow defined]"

        lines = ['graph TD']
        lines.append('    Start[Start Deployment]')

        prev = 'Start'
        for i, step in enumerate(flow):
            step_id = f"Step{i}"
            step_name = step.replace('-', ' ').title()
            lines.append(f"    {step_id}[{step_name}]")
            lines.append(f"    {prev} --> {step_id}")
            prev = step_id

        lines.append(f"    {prev} --> End[Complete]")

        return '\n'.join(lines)

    def generate_mermaid_architecture(self) -> str:
        """Generate Mermaid architecture diagram based on detected pattern."""
        pattern = self.analysis['architecture_pattern']
        services = self.analysis['services']

        if pattern == 'three-tier':
            return self._generate_three_tier_diagram(services)
        elif pattern.startswith('microservices'):
            return self._generate_microservices_diagram(services)
        else:
            return self.generate_mermaid_service_graph()

    def _generate_three_tier_diagram(self, services: List[Dict]) -> str:
        """Generate three-tier architecture diagram."""
        presentation = []
        application = []
        data = []

        for service in services:
            name = service['name'].lower()
            if name in ['web', 'frontend', 'mobile']:
                presentation.append(service['name'])
            elif name in ['api', 'backend', 'business-logic']:
                application.append(service['name'])
            elif name in ['database', 'db', 'cache', 'redis', 'postgres']:
                data.append(service['name'])

        lines = ['graph TB']
        lines.append('    subgraph Presentation["Presentation Tier"]')
        for svc in presentation:
            lines.append(f"        {svc}[{svc}]")
        lines.append('    end')

        lines.append('    subgraph Application["Application Tier"]')
        for svc in application:
            lines.append(f"        {svc}[{svc}]")
        lines.append('    end')

        lines.append('    subgraph Data["Data Tier"]')
        for svc in data:
            lines.append(f"        {svc}[({svc})]")
        lines.append('    end')

        # Add connections
        for p in presentation:
            for a in application:
                lines.append(f"    {p} --> {a}")

        for a in application:
            for d in data:
                lines.append(f"    {a} --> {d}")

        return '\n'.join(lines)

    def _generate_microservices_diagram(self, services: List[Dict]) -> str:
        """Generate microservices architecture diagram."""
        lines = ['graph TB']

        gateway = None
        service_nodes = []

        for service in services:
            name = service['name']
            if 'gateway' in name.lower():
                gateway = name
            else:
                service_nodes.append(name)

        lines.append('    Client[Client]')

        if gateway:
            lines.append(f"    {gateway}[{gateway}]")
            lines.append(f"    Client --> {gateway}")

            for svc in service_nodes:
                lines.append(f"    {svc}[{svc}]")
                lines.append(f"    {gateway} --> {svc}")
        else:
            for svc in service_nodes:
                lines.append(f"    {svc}[{svc}]")
                lines.append(f"    Client --> {svc}")

        return '\n'.join(lines)

    def to_json(self) -> str:
        """Export analysis as JSON."""
        return json.dumps(self.analysis, indent=2)


def main():
    parser = argparse.ArgumentParser(description='Analyze Taskfile.yml and generate architecture diagrams')
    parser.add_argument('taskfile', nargs='?', default='Taskfile.yml', help='Path to Taskfile.yml (default: Taskfile.yml)')
    parser.add_argument('--format', choices=['mermaid', 'json', 'all'], default='all', help='Output format (default: all)')
    parser.add_argument('--diagram', choices=['services', 'deployment', 'architecture'], help='Specific diagram to generate')

    args = parser.parse_args()

    try:
        analyzer = TaskfileAnalyzer(args.taskfile)

        if args.format == 'json' or args.format == 'all':
            print("# Analysis Results")
            print("```json")
            print(analyzer.to_json())
            print("```")
            print()

        if args.format == 'mermaid' or args.format == 'all':
            if not args.diagram or args.diagram == 'services':
                print("# Service Dependency Graph")
                print("```mermaid")
                print(analyzer.generate_mermaid_service_graph())
                print("```")
                print()

            if not args.diagram or args.diagram == 'deployment':
                print("# Deployment Flow")
                print("```mermaid")
                print(analyzer.generate_mermaid_deployment_flow())
                print("```")
                print()

            if not args.diagram or args.diagram == 'architecture':
                print("# Architecture Diagram")
                print("```mermaid")
                print(analyzer.generate_mermaid_architecture())
                print("```")
                print()

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except yaml.YAMLError as e:
        print(f"Error parsing Taskfile: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
